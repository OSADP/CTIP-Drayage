﻿using Ninject.Modules;
using PAI.Core;
using PAI.Drayage.Optimization.Common;
using PAI.Drayage.Optimization.Function;
using PAI.Drayage.Optimization.Geography;
using PAI.Drayage.Optimization.Model;
using PAI.Drayage.Optimization.Reporting.Services;
using PAI.Drayage.Optimization.Services;

namespace ConsoleDemo
{
    /// <summary>
    /// Configuration class to set up dependancy injection
    /// </summary>
    class MyModule : NinjectModule 
    {
        /// <summary>
        /// Binds the implementation classes to the interfaces for dependancy injection
        /// </summary>
        public override void Load()
        {
            Bind<IDrayageOptimizer>().To<DrayageOptimizer>().InSingletonScope();
            Bind<IPheromoneMatrix>().To<PheromoneMatrix>().InSingletonScope()
                .WithConstructorArgument("initialPheromoneValue", 0.0)
                .WithConstructorArgument("rho", 0.5)
                .WithConstructorArgument("q", 1000.0);
            Bind<IRouteExitFunction>().To<RouteExitFunction>().InSingletonScope();
            Bind<IRouteService>().To<RouteService>().InSingletonScope();
            Bind<IRouteStopDelayService>().To<RouteStopDelayService>().InSingletonScope();
            Bind<IRouteStopService>().To<RouteStopService>().InSingletonScope();
            Bind<IStatisticsService>().To<StatisticsService>().InSingletonScope();
            Bind<IObjectiveFunction>().To<DistanceObjectiveFunction>().InSingletonScope();
            Bind<IRandomNumberGenerator>().To<RandomNumberGenerator>().InSingletonScope();
            Bind<IProbabilityMatrix>().To<ProbabilityMatrix>().InSingletonScope();
            Bind<INodeFactory>().To<NodeFactory>().InSingletonScope();

            Bind<ILogger>().To<NullLogger>().InSingletonScope();
            Bind<INodeService>()
                .To<NodeService>()
                .InSingletonScope()
                .WithConstructorArgument("configuration", new OptimizerConfiguration());
            Bind<IDistanceService>().To<DistanceService>().InSingletonScope();
            Bind<ITravelTimeEstimator>().To<TravelTimeEstimator>().InSingletonScope();

            Bind<IReportingService>().To<ReportingService>().InSingletonScope();    
            Bind<IRouteSanitizer>().To<RouteSanitizer>().InSingletonScope();    
        }
    }
}
