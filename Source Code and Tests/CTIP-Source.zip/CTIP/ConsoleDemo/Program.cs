﻿using System.Collections.Generic;
using Ninject;

using System;
using System.Linq;

using PAI.Drayage.Optimization.Model.Node;
using PAI.Drayage.Optimization.Model.Orders;
using PAI.Drayage.Optimization.Reporting.Services;
using PAI.Drayage.Optimization.Services;

namespace ConsoleDemo
{
    class Program
    {
        private static JobHelper _helper = null;
        /// <summary>
        /// Helper class that configures jobs for optimization
        /// </summary>
        /// <value>
        /// The job helper object.
        /// </value>
        public static JobHelper Helper
        {
            get { return _helper ?? (_helper = new JobHelper()); }
        }


        /// <summary>
        /// Gets or sets the dependancy injection manager.
        /// </summary>
        /// <value>
        /// The dependancy injection manager.
        /// </value>
        public static IKernel Kernel{ get; set; }

        private static void Initialize()
        {
            IKernel kernel = new StandardKernel(new MyModule());
            Kernel = kernel;
        }

        /// <summary>
        /// Gets the service by interface from the dependancy injection manager.
        /// </summary>
        /// <typeparam name="TInterface">The type of the interface to instantiate.</typeparam>
        /// <returns>An object that is the configured implementation of the requested interface.</returns>
        public static TInterface GetService<TInterface>()
        {
            try
            {
                var result = Kernel.Get<TInterface>();
                return result;
            }
            catch (Exception ex)
            {
                throw (ex);
            }
        }

        static void Main(string[] args)
        {
            Initialize();   // Initialization of Ninject - Dependency Injection

            // set up demo data.
            var startLocation = MockData.GetMockLocations(1, "Driver").FirstOrDefault();
            var locations = MockData.GetMockLocations(10);
            var drivers = MockData.GetMockDrivers(3, startLocation);
            var jobs = MockData.GetJobs(4, locations, true);

            // initialize the Optimization service
            var optimizer = GetService<IDrayageOptimizer>();            
            optimizer.Initialize();
            
            // solution iterations
            for (int i = 0; i < 3; i++)
            {
                // build the solution
                var solution = optimizer.BuildSolution(drivers, new Driver()
                    {
                        DisplayName="Placeholder Driver", 
                        StartingLocation = drivers.First().StartingLocation,
                        IsShortHaulEligible = true,
                        IsLongHaulEligible = true,
                        IsHazmatEligible = true,
                        AvailableDrivingHours = 11,
                        AvailableDutyHours = 14
                    },  jobs);


                // generate statistics
                var reportingService = GetService<IReportingService>();
                var solutionPerformance = reportingService.GetSolutionPerformanceStatistics(solution);

                // output results
                Console.WriteLine("Solution Created");
                Console.WriteLine(solution.RouteSolutions.Count.ToString() + " route solutions.");
                Console.WriteLine(solution.UnassignedJobNodes.Count.ToString() + " unassigned jobs.");
                Console.WriteLine(solution.RouteStatistics.TotalTime.ToString() + " : total time.\n");

                // iterate through generated routes
                foreach (var routeSolution in solution.RouteSolutions)
                {
                    Console.WriteLine(string.Format("Solution for Driver {0}\n", routeSolution.DriverNode.Driver.DisplayName));
                    Console.WriteLine(string.Format("\tStart Location -\n\t\t{0}", routeSolution.AllNodes.FirstOrDefault().RouteStops.FirstOrDefault().Location.DisplayName));
                    Console.WriteLine(string.Format("\tStart Time -\n\t\t{0}", routeSolution.DriverNode.Driver.EarliestStartTime));
                    
                    int stopCount = 0;
                    // select the drivers statistics from the truck collection by driver name
                    var driverStatistics =
                        solutionPerformance.TruckStatistics.FirstOrDefault(
                            p => p.Key.DriverNode.Driver.Id == routeSolution.DriverNode.Driver.Id).Value;

                    // iterate through each order
                    foreach (var node in routeSolution.Nodes)
                    {
                        var jn = node as JobNode;
                        Console.WriteLine(string.Format("\n\tOrder {0} - (Priority {1})", jn.Job.DisplayName, jn.Job.Priority));

                        var startStatistics = driverStatistics.RouteSegmentStatistics[0];
                        if (startStatistics.Statistics.TotalWaitTime.TotalSeconds > 0)
                        {
                            Console.WriteLine(string.Format("\t\t\tWait for {0}", startStatistics.Statistics.TotalWaitTime));
                        }

                        //iterate through each stop required for the order
                        foreach (var rs in node.RouteStops)
                        {
                            Console.WriteLine(string.Format("\t\tStop {0}: {1}", ++stopCount, rs.Location.DisplayName));
                            Console.WriteLine(string.Format("\t\t\tWindow {0}: {1}", rs.WindowStart, rs.WindowEnd));

                            try
                            {
                                // display the statistics for the stop
                                var segmentStatistics = driverStatistics.RouteSegmentStatistics[stopCount-1];
                                Console.WriteLine(string.Format("\t\t\tLeave Previous Stop @ {0}", segmentStatistics.StartTime));
                                Console.WriteLine(string.Format("\t\t\tDistance: {0} mi", segmentStatistics.Statistics.TotalTravelDistance));
                                if (segmentStatistics.Statistics.TotalWaitTime.TotalSeconds > 0)
                                {
                                    Console.WriteLine(string.Format("\t\t\tWait for {0}", segmentStatistics.Statistics.TotalWaitTime));                                
                                }
                                Console.WriteLine(string.Format("\t\t\tArrive @ {0}", segmentStatistics.StartTime.Add(segmentStatistics.Statistics.TotalTravelTime).Add(segmentStatistics.Statistics.TotalWaitTime)));
                                Console.WriteLine(string.Format("\t\t\tFinished @ {0}", segmentStatistics.EndTime));
                            }
                            catch (Exception e)
                            {
                                Console.WriteLine("Unable to get statistics");
                                continue;
                            }                            
                        }
                        
                    }
                    Console.WriteLine(string.Format("\n\tEnd -\n\t\t{0}", routeSolution.AllNodes.LastOrDefault().RouteStops.FirstOrDefault().Location.DisplayName));
                }
                // prompt user for permission to continue
                Console.Write("Press any key to ");
                Console.WriteLine(i == 2 ? "exit." : "continue.");

                Console.ReadKey();
            }

        }
    }
}
