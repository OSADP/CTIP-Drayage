﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("PAI.Core")]
[assembly: AssemblyDescription("PAI Core Library")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Productivity Apex Inc.")]
[assembly: AssemblyProduct("PAI.Core")]
[assembly: AssemblyCopyright("Copyright © Productivity Apex Inc. 2013")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("ddb3b821-de5d-4f71-8f5b-75a8175fd6fe")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
