using System.Collections.Generic;

using PAI.Drayage.Optimization.Model.Equipment;
using PAI.Drayage.Optimization.Model.Metrics;

namespace PAI.Drayage.Optimization.Reporting.Model
{
    /// <summary>
    /// A representation of the performance statistics of a truck
    /// </summary>
    public class TruckPerformanceStatistics
    {
        /// <summary>
        /// Gets or sets the state of the route statistics by truck.
        /// </summary>
        /// <value>
        /// The state of the route statistics by truck.
        /// </value>
        public Dictionary<TruckState, RouteStatistics> RouteStatisticsByTruckState { get; set; }

        /// <summary>
        /// Gets or sets the route statistics.
        /// </summary>
        /// <value>
        /// The route statistics.
        /// </value>
        public RouteStatistics RouteStatistics { get; set; }

        /// <summary>
        /// Gets or sets the performance statistics of the truck.
        /// </summary>
        /// <value>
        /// The performance statistics of the truck.
        /// </value>
        public PerformanceStatistics PerformanceStatistics { get; set; }

        /// <summary>
        /// Gets or sets the route segment statistics of the truck.
        /// </summary>
        /// <value>
        /// The route segment statistics of the truck.
        /// </value>
        public IList<RouteSegmentStatistics> RouteSegmentStatistics { get; set; }
    }
}