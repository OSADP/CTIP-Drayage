using System;

using PAI.Drayage.Optimization.Model.Node;

namespace PAI.Drayage.Optimization.Common
{
    /// <summary>
    /// Passes a solution to event handlers
    /// </summary>
    public class SolutionEventArgs : EventArgs
    {
        /// <summary>
        /// Gets or sets the solution.
        /// </summary>
        /// <value>
        /// The solution.
        /// </value>
        public Solution Solution { get; set; }
    }
}