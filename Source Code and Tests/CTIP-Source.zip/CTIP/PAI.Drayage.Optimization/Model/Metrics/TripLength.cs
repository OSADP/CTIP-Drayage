//    Copyright 2013 Productivity Apex Inc.
//        http://www.productivityapex.com/
// 
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
// 
//        http://www.apache.org/licenses/LICENSE-2.0
// 
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.

using System;

namespace PAI.Drayage.Optimization.Model.Metrics
{
    /// <summary>
    /// Represents a trip length
    /// </summary>
    public struct TripLength
    {
        /// <summary>
        /// Gets or sets the distance (mi)
        /// </summary>
        public decimal Distance;

        /// <summary>
        /// Gets or sets the time
        /// </summary>
        public TimeSpan Time;

        /// <summary>
        /// Initializes a new instance of the <see cref="TripLength"/> struct.
        /// </summary>
        /// <param name="distance">The distance.</param>
        /// <param name="time">The time.</param>
        public TripLength(decimal distance, TimeSpan time)
        {
            this.Distance = distance;
            this.Time = time;
        }

        /// <summary>
        /// Returns a <see cref="System.String" /> that represents this instance.
        /// </summary>
        /// <returns>
        /// A <see cref="System.String" /> that represents this instance.
        /// </returns>
        public override string ToString()
        {
            return String.Format("{0}mi {1}", this.Distance, this.Time.ToString());
        }

        #region Operators

        /// <summary>
        /// Implements the operator +.
        /// </summary>
        /// <param name="c1">The left hand operand.</param>
        /// <param name="c2">The right hand operand.</param>
        /// <returns>
        /// The result of the operator.
        /// </returns>
        public static TripLength operator +(TripLength c1, TripLength c2)
        {
            return new TripLength(c1.Distance + c2.Distance, c1.Time + c2.Time);
        }

        /// <summary>
        /// Implements the operator ==.
        /// </summary>
        /// <param name="c1">The left hand operand.</param>
        /// <param name="c2">The right hand operand.</param>
        /// <returns>
        /// The result of the operator.
        /// </returns>
        public static bool operator ==(TripLength c1, TripLength c2)
        {
            return (c1.Distance == c2.Distance && c1.Time == c2.Time);
        }

        /// <summary>
        /// Implements the operator !=.
        /// </summary>
        /// <param name="c1">The left hand operand.</param>
        /// <param name="c2">The right hand operand.</param>
        /// <returns>
        /// The result of the operator.
        /// </returns>
        public static bool operator !=(TripLength c1, TripLength c2)
        {
            return (c1.Distance != c2.Distance || c1.Time != c2.Time);
        }

        /// <summary>
        /// Returns a hash code for this instance.
        /// </summary>
        /// <returns>
        /// A hash code for this instance, suitable for use in hashing algorithms and data structures like a hash table. 
        /// </returns>
        public override int GetHashCode()
        {
            unchecked
            {
                return (this.Distance.GetHashCode()*397) ^ this.Time.GetHashCode();
            }
        }

        /// <summary>
        /// Equalses the specified other.
        /// </summary>
        /// <param name="other">The other.</param>
        /// <returns>true if equal, false otherwise</returns>
        public bool Equals(TripLength other)
        {
            return this.Distance == other.Distance && this.Time.Equals(other.Time);
        }

        /// <summary>
        /// Determines whether the specified <see cref="System.Object" />, is equal to this instance.
        /// </summary>
        /// <param name="obj">The <see cref="System.Object" /> to compare with this instance.</param>
        /// <returns>
        ///   <c>true</c> if the specified <see cref="System.Object" /> is equal to this instance; otherwise, <c>false</c>.
        /// </returns>
        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj)) return false;
            return obj is TripLength && this.Equals((TripLength) obj);
        }

        #endregion

        /// <summary>
        /// The maximum value
        /// </summary>
        public static TripLength MaxValue = new TripLength(decimal.MaxValue, TimeSpan.MaxValue);
        /// <summary>
        /// The minimum value
        /// </summary>
        public static TripLength MinValue = new TripLength(decimal.MinValue, TimeSpan.MinValue);
        
    }
}