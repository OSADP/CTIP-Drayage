﻿using System.Collections.Generic;

using PAI.Drayage.Optimization.Model.Metrics;
    //    Copyright 2013 Productivity Apex Inc.
//        http://www.productivityapex.com/
// 
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
// 
//        http://www.apache.org/licenses/LICENSE-2.0
// 
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.

namespace PAI.Drayage.Optimization.Model.Node
{
    /// <summary>
    /// A container for the optimized routes and any jobs that were unable to be assigned
    /// </summary>
    public class Solution
    {
        /// <summary>
        /// Gets or sets the route solutions.
        /// </summary>
        /// <value>
        /// The route solutions.
        /// </value>
        public List<NodeRouteSolution> RouteSolutions { get; set; }

        /// <summary>
        /// Gets or sets the unassigned job nodes.
        /// </summary>
        /// <value>
        /// The unassigned job nodes.
        /// </value>
        public List<INode> UnassignedJobNodes { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="Solution"/> class.
        /// </summary>
        public Solution()
        {
            this.RouteSolutions = new List<NodeRouteSolution>();
            this.UnassignedJobNodes = new List<INode>();
        }

        /// <summary>
        /// Gets the route statistics.
        /// </summary>
        /// <value>
        /// The route statistics.
        /// </value>
        public RouteStatistics RouteStatistics
        {
            get
            {
                var result = new RouteStatistics();

                foreach (var solution in this.RouteSolutions)
                {
                    result += solution.RouteStatistics;
                }

                return result;
            }
        }

        /// <summary>
        /// Clones this instance.
        /// </summary>
        /// <returns>A copy of the solution</returns>
        public Solution Clone()
        {
            var clone = new Solution();
            foreach (var routeSolution in this.RouteSolutions)
            {
                clone.RouteSolutions.Add(routeSolution.Clone());
            }
            return clone;
        }
    }
}
