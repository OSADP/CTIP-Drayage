﻿using System;

using PAI.Drayage.Optimization.Model.Equipment;
using PAI.Drayage.Optimization.Model.Orders;

namespace PAI.Drayage.Optimization.Services
{
    /// <summary>
    /// Checks route for valid values before sending to optimizer for solution generation
    /// </summary>
    public interface IRouteSanitizer
    {
        /// <summary>
        /// Returns true if route stop is valid
        /// </summary>
        /// <param name="stop">the stop to validate</param>
        /// <returns>true if the stop is appropriately configured, false otherwise</returns>
        bool IsValidRouteStop(RouteStop stop);

        /// <summary>
        /// function that check if the truck configuration is valid.
        /// returns true if valid and false if not
        /// </summary>
        /// <returns>true if the TruckConfiguration is an appropriate value, otherwise false</returns>
        bool IsValidTruckConfig(TruckConfiguration truckConfiguration);

        /// <summary>
        /// Prepares a job for optimization
        /// </summary>
        /// <param name="job">the generated job object</param>
        void PrepareJob(Job job);
    }

    /// <summary>
    /// Checks routes for valid values and states before sending the route through the optimization algorithm
    /// </summary>
    public class RouteSanitizer : IRouteSanitizer
    {
        /// <summary>
        /// Returns true if route stop is valid
        /// </summary>
        /// <param name="stop">the stop to check</param>
        /// <returns>true if the stop is properly configured, otherwise false</returns>
        public bool IsValidRouteStop(RouteStop stop)
        {
            if ((stop.StopAction.PreState & stop.PreTruckConfig.TruckState) != stop.PreTruckConfig.TruckState)
            {
                return false;
            }

            if (!this.IsValidTruckConfig(stop.PreTruckConfig))
            {
                return false;
            }

            if (!this.IsValidTruckConfig(stop.PostTruckConfig))
            {
                return false;
            }

            return true;
        }

        /// <summary>
        /// function that check if the truck configuration is valid.
        /// </summary>
        /// <returns>true if valid, otherwise false</returns>
        public bool IsValidTruckConfig(TruckConfiguration truckConfiguration)
        {
            var t = truckConfiguration;

            if ((t.EquipmentConfiguration.Container == null && t.IsLoaded) || (t.EquipmentConfiguration.Chassis == null && t.IsLoaded))
            {
                return false;
            }

            if (t.EquipmentConfiguration.Container != null && t.EquipmentConfiguration.ContainerOwner == null || t.EquipmentConfiguration.Container == null && t.EquipmentConfiguration.ContainerOwner != null)
            {
                return false;
            }

            if ((t.TruckState == TruckState.Bobtail || t.TruckState == TruckState.Chassis) && t.IsLoaded)
            {
                return false;
            }

            if (t.TruckState == TruckState.Bobtail && t.IsLoaded)
            {
                return false;
            }

            if ((t.TruckState == TruckState.Loaded && !t.IsLoaded) || (t.TruckState != TruckState.Loaded && t.IsLoaded))
            {
                return false;
            }

            if (t.TruckState == TruckState.Empty && t.IsLoaded)
            {
                return false;
            }

            return true;
        }

        /// <summary>
        /// Prepares a job for optimization
        /// </summary>
        /// <param name="job">the generated job object</param>
        public void PrepareJob(Job job)
        {
            RouteStop previousStop = null;
            foreach (var routeStop in job.RouteStops)
            {
                this.PrepareRouteStop(routeStop, previousStop, job.EquipmentConfiguration);
                previousStop = routeStop;
            }
        }

        /// <summary>
        /// Prepares the route stop.
        /// </summary>
        /// <param name="result">The stop to prepare</param>
        /// <param name="previousStop">The previous stop.</param>
        /// <param name="equipment">The equipment configuration for the stoop.</param>
        /// <exception cref="System.Exception">
        /// Live action cannot be the first stop of an order
        /// or
        /// Invalid Route Stop
        /// </exception>
        public void PrepareRouteStop(RouteStop result, RouteStop previousStop, EquipmentConfiguration equipment)
        {

            if (result.StopAction == StopActions.LiveLoading || result.StopAction == StopActions.LiveUnloading)
            {
                if (previousStop == null)
                {
                    throw new Exception("Live action cannot be the first stop of an order");
                }

                result.PreTruckConfig = new TruckConfiguration()
                {
                    EquipmentConfiguration = new EquipmentConfiguration()
                    {
                        Chassis = previousStop.PostTruckConfig.EquipmentConfiguration.Chassis,
                        ChassisOwner = previousStop.PostTruckConfig.EquipmentConfiguration.ChassisOwner,
                        Container = previousStop.PostTruckConfig.EquipmentConfiguration.Container,
                        ContainerOwner = previousStop.PostTruckConfig.EquipmentConfiguration.ContainerOwner,
                    },
                    IsLoaded = previousStop.PostTruckConfig.IsLoaded
                };

                result.PostTruckConfig = new TruckConfiguration()
                {
                    EquipmentConfiguration = new EquipmentConfiguration()
                    {
                        Chassis = previousStop.PostTruckConfig.EquipmentConfiguration.Chassis,
                        ChassisOwner = previousStop.PostTruckConfig.EquipmentConfiguration.ChassisOwner,
                        Container = previousStop.PostTruckConfig.EquipmentConfiguration.Container,
                        ContainerOwner = previousStop.PostTruckConfig.EquipmentConfiguration.ContainerOwner,
                    },
                    IsLoaded = previousStop.PostTruckConfig.IsLoaded
                };

                if (result.StopAction == StopActions.LiveLoading)
                {
                    result.PostTruckConfig.IsLoaded = true;
                }

                if (result.StopAction == StopActions.LiveUnloading)
                {
                    result.PostTruckConfig.IsLoaded = false;

                    // mark previous live unloading stop as loaded
                    if (previousStop.StopAction == StopActions.LiveUnloading)
                    {
                        previousStop.PostTruckConfig.IsLoaded = true;
                        result.PreTruckConfig.IsLoaded = true;
                    }
                }

            }

            else
            {
                result.PreTruckConfig = this.GetTruckConfigForAction(result.StopAction.PreState, equipment);
                result.PostTruckConfig = this.GetTruckConfigForAction(result.StopAction.PostState, equipment);
            }

            if (!this.IsValidRouteStop(result))
            {
                throw new Exception("Invalid Route Stop");
            }
        }

        /// <summary>
        /// Gets the truck configuration for a truck state.
        /// </summary>
        /// <param name="truckState">State of the truck.</param>
        /// <param name="equipment">The equipment configuration of the truck.</param>
        /// <returns>a configured Truck Configuration</returns>
        public TruckConfiguration GetTruckConfigForAction(TruckState truckState, EquipmentConfiguration equipment)
        {
            TruckConfiguration truckConfiguration = null;

            switch (truckState)
            {
                case TruckState.Chassis:
                    truckConfiguration = new TruckConfiguration()
                    {
                        EquipmentConfiguration = new EquipmentConfiguration()
                        {
                            Chassis = equipment.Chassis,
                            ChassisOwner = equipment.ChassisOwner,
                        }
                    };

                    break;

                case TruckState.Empty:

                    truckConfiguration = new TruckConfiguration()
                    {
                        EquipmentConfiguration = new EquipmentConfiguration()
                        {
                            Chassis = equipment.Chassis,
                            ChassisOwner = equipment.ChassisOwner,
                            Container = equipment.Container,
                            ContainerOwner = equipment.ContainerOwner,
                        }
                    };


                    break;

                case TruckState.Loaded:

                    truckConfiguration = new TruckConfiguration()
                    {
                        IsLoaded = true,
                        EquipmentConfiguration = new EquipmentConfiguration()
                        {
                            Chassis = equipment.Chassis,
                            ChassisOwner = equipment.ChassisOwner,
                            Container = equipment.Container,
                            ContainerOwner = equipment.ContainerOwner,
                        }
                    };

                    break;

                default:
                    truckConfiguration = new TruckConfiguration();
                    break;
            }

            return truckConfiguration;
        }
    }

}