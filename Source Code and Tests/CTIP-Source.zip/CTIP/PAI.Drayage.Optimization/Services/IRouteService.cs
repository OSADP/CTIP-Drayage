using System.Collections.Generic;

using PAI.Drayage.Optimization.Model.Metrics;
using PAI.Drayage.Optimization.Model.Node;
using PAI.Drayage.Optimization.Model.Orders;
    //    Copyright 2013 Productivity Apex Inc.
//        http://www.productivityapex.com/
// 
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
// 
//        http://www.apache.org/licenses/LICENSE-2.0
// 
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.

namespace PAI.Drayage.Optimization.Services
{
    /// <summary>
    /// Interface for interacting with and between routes
    /// </summary>
    public interface IRouteService
    {
        /// <summary>
        /// Calculates the trip length between two nodes
        /// </summary>
        /// <param name="origin">the beginning of the route</param>
        /// <param name="destination">the end of the route</param>
        /// <returns></returns>
        RouteStatistics CalculateRouteStatistics(INode origin, INode destination);
        
        /// <summary>
        /// Creates a route solution from a list of nodes
        /// </summary>
        /// <param name="nodes">a list of nodes that comprise a route</param>
        /// <returns>a generated route with applicable statistics, driver, and times</returns>
        NodeRouteSolution CreateRouteSolution(IEnumerable<INode> nodes, DriverNode driverNode);

        /// <summary>
        /// Gets the best solution between a new list of <see cref="INode"/> and a current best <see cref="NodeRouteSolution"/>
        /// </summary>
        /// <param name="nodes">a list of nodes that comprise a route</param>
        /// <param name="driverNode">the driver of the route</param>
        /// <param name="bestSolution">the currently best generated route</param>
        /// <returns>the best solution</returns>
        NodeRouteSolution GetBestFeasableSolution(IList<INode> nodes, DriverNode driverNode, NodeRouteSolution bestSolution);

        /// <summary>
        /// Gets the best solution.
        /// </summary>
        /// <param name="left">The left hand opernad of the comparison.</param>
        /// <param name="right">The right hand opernad of the comparison.</param>
        /// <returns>the better solution</returns>
        NodeRouteSolution GetBestSolution(NodeRouteSolution left, NodeRouteSolution right);

        /// <summary>
        /// Gets the best solution.
        /// </summary>
        /// <param name="left">The left hand opernad of the comparison.</param>
        /// <param name="right">The right hand opernad of the comparison.</param>
        /// <returns>the better solution</returns>
        Solution GetBestSolution(Solution left, Solution right);

        /// <summary>
        /// Gets the route stops for route solution.
        /// </summary>
        /// <param name="routeSolution">The route solution.</param>
        /// <returns>a list of stops that comprise the generated solution</returns>
        IList<RouteStop> GetRouteStopsForRouteSolution(NodeRouteSolution routeSolution);
    }
}