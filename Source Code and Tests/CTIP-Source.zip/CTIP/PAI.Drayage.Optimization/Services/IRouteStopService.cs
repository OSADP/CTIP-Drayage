using System;
using System.Collections.Generic;

using PAI.Drayage.Optimization.Model.Metrics;
using PAI.Drayage.Optimization.Model.Orders;
    //    Copyright 2013 Productivity Apex Inc.
//        http://www.productivityapex.com/
// 
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
// 
//        http://www.apache.org/licenses/LICENSE-2.0
// 
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.

namespace PAI.Drayage.Optimization.Services
{
    /// <summary>
    /// Interface for interacting with and between stops along a route
    /// </summary>
    public interface IRouteStopService
    {
        /// <summary>
        /// Calculates the trip length between two stops
        /// </summary>
        /// <param name="start">the beginning stop of a route leg</param>
        /// <param name="end">the ending stop of a route leg</param>
        /// <returns>a representation of a trip time and distance</returns>
        TripLength CalculateTripLength(RouteStop start, RouteStop end);
        
        /// <summary>
        /// Calculates the route statistics for a list of stops
        /// </summary>
        /// <param name="stops">a list of stops comprising a route</param>
        /// <param name="ignoreFirstStopDelays">true to skip the first step of a route (usually for a drivers home), otherwise false</param>
        /// <returns>the quantified measurement statistics for a route</returns>
        RouteStatistics CalculateRouteStatistics(IList<RouteStop> stops, bool ignoreFirstStopDelays = false);
        
        /// <summary>
        /// Calculates the route segment statistics for a list of stops
        /// </summary>
        /// <param name="stops">a list of stops comprising a route</param>
        /// <param name="startTime">the time a route is started</param>
        /// <returns>a list of statistics covering the legs of a route</returns>
        IList<RouteSegmentStatistics> CalculateRouteSegmentStatistics(IList<RouteStop> stops, TimeSpan startTime);

        /// <summary>
        /// Creates a route segment statistics
        /// </summary>
        /// <param name="startTime">the time a route leg is to begin</param>
        /// <param name="startStop">the beginning point of a route leg</param>
        /// <param name="endStop">the ending location of the route leg</param>
        /// <returns></returns>
        RouteSegmentStatistics CreateRouteSegmentStatistics(TimeSpan startTime, RouteStop startStop, RouteStop endStop);

    }
}
