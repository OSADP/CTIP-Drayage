using System;
using System.Collections.Generic;

using PAI.Drayage.Optimization.Function;
using PAI.Drayage.Optimization.Model.Node;
    //    Copyright 2013 Productivity Apex Inc.
//        http://www.productivityapex.com/
// 
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
// 
//        http://www.apache.org/licenses/LICENSE-2.0
// 
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.

namespace PAI.Drayage.Optimization.Services
{
    /// <summary>
    /// Represents a pheromone matrix, modifying probability values for subsequent solution generation runs, so that successful sub routes are more likely to be selected
    /// </summary>
    public class PheromoneMatrix : IPheromoneMatrix
    {
        private readonly IDictionary<Tuple<INode, INode>, double> _pheromoneMatrix;
        private readonly IObjectiveFunction _objectiveFunction;
        private Dictionary<INode, double> _initialValues;

        /// <summary>
        /// Initializes a new instance of the <see cref="PheromoneMatrix"/> class.
        /// </summary>
        /// <param name="initialPheromoneValue">The initial pheromone value.</param>
        /// <param name="rho">The rho.</param>
        /// <param name="q">The q.</param>
        /// <param name="objectiveFunction">The objective function.</param>
        public PheromoneMatrix(double initialPheromoneValue, double rho, double q, IObjectiveFunction objectiveFunction)
        {
            this.InitialPheromoneValue = initialPheromoneValue;
            this.Rho = rho;
            this.Q = q;

            this._objectiveFunction = objectiveFunction;
            this._pheromoneMatrix = new Dictionary<Tuple<INode, INode>, double>();
        }


        /// <summary>
        /// Gets or sets the initial pheromone value
        /// </summary>
        public double InitialPheromoneValue { get; set; }

        /// <summary>
        /// Gets or sets the pheromone evaporation rate
        /// </summary>
        public double Rho { get; set; }

        /// <summary>
        /// Gets or sets the performance measure coeficient
        /// </summary>
        public double Q { get; set; }

        /// <summary>
        /// Clears the pheromone matrix
        /// </summary>
        public virtual void Clear()
        {
            this._pheromoneMatrix.Clear();    
        }

        /// <summary>
        /// Gets the value
        /// </summary>
        /// <param name="origin">the start node of pheromone trail</param>
        /// <param name="destination">the end node of pheromone trail</param>
        /// <returns>the pheromone value</returns>
        public virtual double GetValue(INode origin, INode destination)
        {
            double value;
            if (!this._pheromoneMatrix.TryGetValue(new Tuple<INode, INode>(origin, destination), out value))
            {
                value = this.GetInitialValue(new[] { origin, destination });
            }
            
            return value;
        }

        /// <summary>
        /// Gets the initial pheromone value for the provided nodes
        /// If multiple nodes have an initial value override set, then
        /// the highest value is returned.
        /// </summary>
        /// <param name="nodes">the list of nodes to retrieve pheromone values from</param>
        /// <returns>the argest pheromone value</returns>
        public virtual double GetInitialValue(IEnumerable<INode> nodes)
        {
            var initialValue = this.InitialPheromoneValue;
            if (this._initialValues != null)
            {
                foreach (var node in nodes)
                {
                    double i;
                    if (this._initialValues.TryGetValue(node, out i))
                    {
                        if (i > initialValue)
                        {
                            initialValue = i;
                        }
                    }
                }                
            }
            return initialValue;
        }

        /// <summary>
        /// Dictionary of initial values for the pheromone matrix
        /// </summary>
        /// <param name="values">a collection of initial probability values indexed by node</param>
        public void SetInitialValues(Dictionary<INode, double> values)
        {
            this._initialValues = new Dictionary<INode, double>();
            foreach (var kvp in values)
            {
                this._initialValues[kvp.Key] = kvp.Value;
            }
        }

        /// <summary>
        /// Sets the Pheromone Matrix value
        /// </summary>
        /// <param name="origin">the beginning location of the ant trail</param>
        /// <param name="destination">the ending location of the ant trail</param>
        /// <param name="value">the probability value to set on the route from origin to destination</param>
        public virtual void SetValue(INode origin, INode destination, double value)
        {
            this._pheromoneMatrix[new Tuple<INode, INode>(origin, destination)] = value;
        }

        /// <summary>
        /// Updates the pheromone matrix 
        /// </summary>
        /// <param name="nodes">the list of nodes to update</param>
        /// <param name="performanceMeasure">the denominator that divides the Q value used to update the pheronome value.  When 0, sets the pheronome value to zero</param>
        public virtual void UpdatePheromoneMatrix(IList<INode> nodes, double performanceMeasure)
        {
            for (int i = 0; i < (nodes.Count - 1); i++)
            {
                var key = new Tuple<INode, INode>(nodes[i], nodes[i + 1]);

                double pheromone = 0;
                if (!this._pheromoneMatrix.TryGetValue(key, out pheromone))
                {
                    pheromone = this.GetInitialValue(new[] { nodes[i], nodes[i + 1] });
                }

                if (performanceMeasure == 0)
                {
                    pheromone = 0;
                }
                else
                {
                    pheromone = (this.Rho * pheromone) + (this.Q / performanceMeasure);
                }

                //update matrix
                this._pheromoneMatrix[key] = pheromone;
            }
        }
        
        /// <summary>
        /// Updates the pheromone matrix
        /// </summary>
        /// <param name="solution">the solution from which the matrix will be updated</param>
        public virtual void UpdatePheromoneMatrix(Solution solution)
        {
            if (solution == default(Solution))
            {
                throw new ArgumentNullException("Solution cannot be null");
            }

            double performanceMeasure = this._objectiveFunction.GetObjectiveMeasure(solution.RouteStatistics);

            foreach (var routeSolution in solution.RouteSolutions)
            {
                this.UpdatePheromoneMatrix(routeSolution.AllNodes, performanceMeasure);
            }
        }
    }
}