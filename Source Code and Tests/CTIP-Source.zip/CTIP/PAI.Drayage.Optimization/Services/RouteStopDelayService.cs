using System;

using PAI.Drayage.Optimization.Model;
using PAI.Drayage.Optimization.Model.Orders;
    //    Copyright 2013 Productivity Apex Inc.
//        http://www.productivityapex.com/
// 
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
// 
//        http://www.apache.org/licenses/LICENSE-2.0
// 
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.

namespace PAI.Drayage.Optimization.Services
{
    /// <summary>
    /// Provides resources for interacting with and determining time spent at stops
    /// </summary>
    public class RouteStopDelayService : IRouteStopDelayService
    {
        private readonly OptimizerConfiguration _optimizerConfiguration;

        public RouteStopDelayService(OptimizerConfiguration optimizerConfiguration)
        {
            this._optimizerConfiguration = optimizerConfiguration;
        }

        /// <summary>
        /// Gets the approximate delay (minutes) for the given stop
        /// </summary>
        /// <param name="stopAction">type of action performed at the stoop</param>
        /// <returns>duration of activity</returns>
        public TimeSpan GetDelay(StopAction stopAction)
        {
            if (stopAction == StopActions.NoAction)
                return TimeSpan.Zero;

            return this._optimizerConfiguration.DefaultStopDelay;
        }

        /// <summary>
        /// Gets the approximate delay (minutes) for the given stop and location
        /// </summary>
        /// <param name="stopAction">type of action performed at the stoop</param>
        /// <param name="location">location of stop</param>
        /// <returns>duration of activity</returns>
        public TimeSpan GetDelay(StopAction stopAction, Location location)
        {
            return this.GetDelay(stopAction);
        }

        /// <summary>
        /// Gets the approximate delay (minutes) for the given <see cref="RouteStop"/>
        /// </summary>
        /// <param name="routeStop">the stop to be estimated</param>
        /// <returns>duration of activity</returns>
        public TimeSpan GetDelay(RouteStop routeStop)
        {
            if (routeStop.StopDelay.HasValue)
                return routeStop.StopDelay.Value;

            return this.GetDelay(routeStop.StopAction, routeStop.Location);
        }
    }
}