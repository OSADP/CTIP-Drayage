using System;
using System.Collections.Generic;

using PAI.Drayage.Optimization.Geography;
using PAI.Drayage.Optimization.Model;
using PAI.Drayage.Optimization.Model.Metrics;
using PAI.Drayage.Optimization.Model.Orders;
    //    Copyright 2013 Productivity Apex Inc.
//        http://www.productivityapex.com/
// 
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
// 
//        http://www.apache.org/licenses/LICENSE-2.0
// 
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.

namespace PAI.Drayage.Optimization.Services
{
    /// <summary>
    /// Handles interactions with and between RouteStops
    /// </summary>
    public class RouteStopService : IRouteStopService
    {
        private readonly IDistanceService _distanceService;
        private readonly OptimizerConfiguration _configuration;
        private readonly IRouteStopDelayService _routeStopDelayService;

        /// <summary>
        /// Initializes a new instance of the <see cref="RouteStopService"/> class.
        /// </summary>
        /// <param name="distanceService">The distance service.</param>
        /// <param name="configuration">The configuration options.</param>
        /// <param name="routeStopDelayService">The route stop delay service.</param>
        public RouteStopService(IDistanceService distanceService, OptimizerConfiguration configuration, IRouteStopDelayService routeStopDelayService)
        {
            this._distanceService = distanceService;
            this._configuration = configuration;
            this._routeStopDelayService = routeStopDelayService;
        }

        /// <summary>
        /// Calculates the trip length between two stops
        /// </summary>
        /// <param name="start">the beginning location of the route</param>
        /// <param name="end">the ending location of the route</param>
        /// <returns>the time and distance estimated for the trip</returns>
        public TripLength CalculateTripLength(RouteStop start, RouteStop end)
        {
            return this._distanceService.CalculateDistance(start.Location, end.Location);
        }
        
        /// <summary>
        /// Calculates the toal route statistics a list of route stops
        /// </summary>
        /// <param name="stops">a list of stops comprising the route to calculate</param>
        /// <param name="ignoreFirstStopDelays">if true, ignores the first stop in determining statistics, otherwise includes the first stop</param>
        /// <returns>the calculated trip values for the list of stops</returns>
        public RouteStatistics CalculateRouteStatistics(IList<RouteStop> stops, bool ignoreFirstStopDelays = false)
        {
            var result = new RouteStatistics();

            for (int i = 0; i < stops.Count; i++)
            {
                var currentStop = stops[i];

                if (!ignoreFirstStopDelays && (i == 0 || i == stops.Count - 1))
                {
                    var executionTime = this._routeStopDelayService.GetDelay(currentStop);

                    var staticStats = new RouteStatistics()
                        {
                            TotalExecutionTime = executionTime,
                        };
                    result += staticStats;
                }

                // add travel cost
                if (i < stops.Count - 1)
                {
                    var nextStop = stops[i + 1];

                    // calculate the trip between the current and next stop
                    var tripLength = this.CalculateTripLength(currentStop, nextStop);
                    var travelStats = new RouteStatistics()
                        {
                            TotalTravelTime = tripLength.Time,
                            TotalTravelDistance = tripLength.Distance,
                        };
                    result += travelStats;
                }
            }

            return result;
        }
        
        /// <summary>
        /// Calculates the toal route statistics a list of route stops
        /// </summary>
        /// <param name="stops">a list of stops comprising the route to calculate</param>
        /// <returns>the time and distance estimated for the trip</returns>
        public TripLength CalculateTripLength(IList<RouteStop> stops)
        {
            var result = new TripLength();

            for (int i = 0; i < stops.Count - 1; i++)
            {
                // calculate the trip between the current and next stop
                var currentStop = stops[i];
                var nextStop = stops[i + 1];

                var tripLength = this.CalculateTripLength(currentStop, nextStop);

                result += tripLength;
            }

            return result;
        }
        
        /// <summary>
        /// Calculates the route segment statistics for a list of stops
        /// </summary>
        /// <param name="stops">a list of stops comprising the route to calculate</param>
        /// <param name="startTime">the time the trip is initiated</param>
        /// <returns>a list of statistics representing the legs of the trip</returns>
        public IList<RouteSegmentStatistics> CalculateRouteSegmentStatistics(IList<RouteStop> stops, TimeSpan startTime)
        {
            var result = new List<RouteSegmentStatistics>();

            var currentTime = startTime;

            for (int i = 0; i < stops.Count - 1; i++)
            {
                var startStop = stops[i];
                var endStop = stops[i + 1];

                var segment = this.CreateRouteSegmentStatistics(currentTime, startStop, endStop);
                currentTime = segment.EndTime;

                result.Add(segment);
            }

            return result;
        }

        /// <summary>
        /// Creates a route segment statistics
        /// </summary>
        /// <param name="startTime">the time that the travel begins</param>
        /// <param name="startStop">the beginning location of the trip</param>
        /// <param name="endStop">the ending location of the trip</param>
        /// <returns>An estimation of the leg between startStop and endStop that begins at startTime</returns>
        public RouteSegmentStatistics CreateRouteSegmentStatistics(TimeSpan startTime, RouteStop startStop, RouteStop endStop)
        {
            // determine if time arrived within time window and calculate wait time
            bool early = startTime < endStop.WindowStart;
            bool late = startTime > endStop.WindowEnd;

            TimeSpan waitTime = TimeSpan.Zero;
            bool whiffed = false;

            if (early)
            {
                waitTime = endStop.WindowStart.Subtract(startTime);
                whiffed = waitTime > this._configuration.MaximumWaitTimeAtStop;
            }
            else if (late)
            {
                // we started past the time window
                whiffed = true;
            }

            var executionTime = this._routeStopDelayService.GetDelay(endStop);

            // calculate the trip between the current and next stop
            var tripLength = this.CalculateTripLength(startStop, endStop);

            var routeStatistics = new RouteStatistics()
            {
                TotalExecutionTime = executionTime,
                TotalWaitTime = waitTime,
                TotalTravelTime = tripLength.Time,
                TotalTravelDistance = tripLength.Distance,
            };
            
            var result = new RouteSegmentStatistics
                {
                    StartStop = startStop,
                    EndStop = endStop,
                    StartTime = startTime,
                    Statistics = routeStatistics,
                    WhiffedTimeWindow = whiffed
                };
            
            return result;
        }
    }
}