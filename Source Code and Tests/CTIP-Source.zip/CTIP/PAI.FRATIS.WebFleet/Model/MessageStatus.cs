﻿namespace PAI.FRATIS.Wrappers.WebFleet.Model
{
    public enum MessageStatus
    {
        Unspecified = 0,
        Received = 1,
        Read = 2,
        Informational = 3
    }
}
