﻿namespace PAI.FRATIS.Wrappers.WebFleet.Model
{
    public enum WebFleetColors
    {
        Unspecified,
        BrightBlue,
        DullOrange,
        BrightOrange,
        BrightPaleGreen,
        GrassGreen,
        BrightPurple,
        DarkRed,
        DullAzure,
        DeepPurple,
        BrightAzure,
        OrangeHighlight,
        BrightGreen,
        BrightOrangeHighlight,
        Khaki,
        PaleBlue,
        Turquoise
    }
}
