﻿using System;

namespace PAI.FRATIS.Wrappers.WebFleet.Model
{
    public class WebFleetDestinationEstimate
    {
        public DateTime? ArrivalTime { get; set; }

        public double Distance { get; set; } 

    }
}
