﻿using System;

namespace PAI.FRATIS.Wrappers.WebFleet.Model
{
    public class WebFleetDistance
    {
        public double Meters { get; private set; }

        public double Miles { get; private set; }

        public WebFleetDistance(string meters)
        {
            var dblMeters = 0.0;
            Double.TryParse(meters, out dblMeters);

            Meters = dblMeters;
            Miles = Meters*.000621371;
        }
    }
}
