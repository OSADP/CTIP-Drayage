﻿namespace PAI.FRATIS.Wrappers.WebFleet.Model
{
    public class WebFleetDriver
    {
        public string ObjectNumber { get; set; }

        public string DriverNumber { get; set; }

        public string Name { get; set; }

        public string Company { get; set; }

        public string Pin { get; set; }

        public string Code { get; set; }

        public string Email { get; set; }

        public string Phone { get; set; }

        public string CurrentVehicleObjectNumber { get; set; }

        public WebFleetPosition CurrentPosition { get; set; }

        public WebFleetDriverWorkInfo WorkInfo { get; set; }
    }
}
