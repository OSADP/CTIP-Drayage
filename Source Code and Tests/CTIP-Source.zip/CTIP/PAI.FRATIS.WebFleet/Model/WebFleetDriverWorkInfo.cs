﻿using System;

namespace PAI.FRATIS.Wrappers.WebFleet.Model
{
    public class WebFleetDriverWorkInfo
    {
        public WebFleetWorkState Status { get; set; }

        public DateTime? StartTime { get; set; }

        public DateTime? EndTime { get; set; }

        public TimeSpan? WorkTimeSpan { get; set; }
    }

    public enum WebFleetWorkState
    {
        Unknown,
        Driving,
        FreeTime,
        Other,
        Pause,
        StandBy,
        Working
    }
}
