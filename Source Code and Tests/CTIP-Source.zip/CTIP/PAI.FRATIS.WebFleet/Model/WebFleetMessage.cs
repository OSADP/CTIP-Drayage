﻿using System;

namespace PAI.FRATIS.Wrappers.WebFleet.Model
{
    public class WebFleetMessage
    {
        public long MessageId { get; set; }

        public DateTime MessageTime { get; set; }

        public string MessageText { get; set; }

        public string PositionText { get; set; }

        public string ObjectNumber { get; set; }

        public MessageStatus Status { get; set; }

        public InformationalStatusType InformationalStatusType { get; set; }
        
        public string InformationStatusPositionText { get; set; }
    }
}
