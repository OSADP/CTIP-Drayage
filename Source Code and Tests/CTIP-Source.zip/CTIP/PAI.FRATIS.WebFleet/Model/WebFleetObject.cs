﻿using System;

namespace PAI.FRATIS.Wrappers.WebFleet.Model
{
    public class WebFleetObject
    {
        public string ObjectNumber { get; set; }

        public string ObjectName { get; set; }

        public string ObjectTypeString
        {
            get { return ObjectType.ToString(); }
            set
            {
                try { ObjectType = (WebFleetObjectType) Enum.Parse(typeof (WebFleetObjectType), value, true); }
                catch { ObjectType = WebFleetObjectType.Unspecified; }
            }

        }

        public string LicensePlate { get; set; }

        public WebFleetObjectType ObjectType { get; set; }

        public string Description { get; set; }

        public string PositionText { get; set; }

        public long Odometer { get; set; }

        public WebFleetPosition Position { get; set; }

        public WebFleetPosition DestinationPosition { get; set; }

        public WebFleetDestinationEstimate DestinationEstimate { get; set; }
        
    }
}
