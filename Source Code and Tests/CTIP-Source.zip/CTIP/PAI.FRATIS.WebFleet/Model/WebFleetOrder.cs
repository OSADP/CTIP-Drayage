﻿using System;

namespace PAI.FRATIS.Wrappers.WebFleet.Model
{
    public class WebFleetOrder
    {
        public string OrderNumber { get; set; }
        public string ObjectNumber { get; set; }
        public DateTime? OrderDate { get; set; }
        public WebFleetOrderType OrderType { get; set; }
        public int OrderTypeInt
        {
            get { return (int) OrderType; }
        }

        public WebFleetOrderState OrderState { get; set; }

        public string OrderText { get; set; }
        
        public string DriverNumber { get; set; }
        public string DriverName { get; set; }
        
        public WebFleetPosition OrderPosition { get; set; }
        public WebFleetAddress OrderAddress { get; set; }
        
    }
}