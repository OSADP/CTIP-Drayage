﻿namespace PAI.FRATIS.Wrappers.WebFleet.Model
{
    public enum WebFleetOrderState : int
    {
        NotYetSent = 0,
        Sent = 100,
        Received = 101,
        Read = 102,
        Accepted = 103,
        ServiceOrderStarted = 201,
        ArrivedAtDestination = 202,
        WorkStarted = 203,
        WorkFinished = 204,
        DepartedFromDestination = 205,
        PickupOrderStarted = 221,
        ArrivedAtPickUpLocation = 222,
        PickUpStarted = 223,
        PickUpFinished = 224,
        DepartedFromPickUpLocation = 225,
        DeliveryOrderStarted = 241,
        ArrivedAtDeliveryLocation = 242,
        DeliveryStarted = 243,
        DeliveryFinished = 244,
        DepartedFromDeliveryLocation = 245,
        Resumed = 298,
        Suspended = 299,
        Cancelled = 301,
        Rejected = 302,
        Finished = 401
    }
}
