﻿namespace PAI.FRATIS.Wrappers.WebFleet.Model
{
    public enum WebFleetOrderType : int
    {
        Unspecified = 0,
        ServiceOrder = 1,
        PickupOrder = 2,
        DeliveryOrder = 3
    }
}
