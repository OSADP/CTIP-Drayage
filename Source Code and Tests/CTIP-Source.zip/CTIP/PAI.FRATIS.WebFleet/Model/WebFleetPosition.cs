﻿using System;

namespace PAI.FRATIS.Wrappers.WebFleet.Model
{
    public class WebFleetPosition
    {
        public DateTime? TimeStamp { get; set; }

        public double? Latitude { get; set; }

        public double? Longitude { get; set; }

        public int? LatitudeInt
        {
            get { return Latitude != null ? Convert.ToInt32(Latitude*1000000) : 0; }
            set { if (value != null) Latitude = value*.000001; }
        }

        public int? LongitudeInt
        {
            get { return Longitude != null ? Convert.ToInt32(Longitude * 1000000) : 0; }
            set { if (value != null) Longitude = value * .000001; }
        }

        public string PositionText { get; set; }

        public string PositionTextShort { get; set; }

        public WebFleetPositionMovement PositionMovement { get; set; }

        public bool HasValidPoints()
        {
            return Latitude != null && Longitude != null;
        }
    }
}
