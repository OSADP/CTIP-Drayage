﻿using System;

namespace PAI.FRATIS.Wrappers.WebFleet.Model
{
    public class WebFleetPositionEntry
    {
        public DateTime? TimeStamp { get; set; }

        public long DriverNumber { get; set; }

        public long ObjectNumber { get; set; }

        public WebFleetPosition Position { get; set; }

        public WebFleetPositionMovement PositionMovement { get; set; }
    }
}
