﻿namespace PAI.FRATIS.Wrappers.WebFleet.Model
{
    public class WebFleetPositionMovement
    {
        public string GpsStatus { get; set; }

        public string Speed { get; set; }

        public int Course { get; set; }

        public DirectionEnum Direction { get; set; } 

    }
}
