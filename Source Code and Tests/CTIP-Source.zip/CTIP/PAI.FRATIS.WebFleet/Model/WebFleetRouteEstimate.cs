﻿using System;

namespace PAI.FRATIS.Wrappers.WebFleet.Model
{
    public class WebFleetRouteEstimate
    {
        public DateTime? ArrivalDateTime { get; set; }

        public string TripDurationSeconds { get; set; }

        public TimeSpan TripDuration
        {
            get
            {
                var seconds = 0;
                Int32.TryParse(TripDurationSeconds, out seconds);
                return new TimeSpan(0, 0, seconds);
            }
            set
            {
                TripDurationSeconds = value.TotalSeconds.ToString();
            }
        }

        public WebFleetDistance Distance { get; set; }
        
        public long DelaySeconds { get; set; }

        public TimeSpan Delay
        {
            get
            {
                return new TimeSpan(0, 0, Convert.ToInt32(DelaySeconds));
            }
        }
    }
}
