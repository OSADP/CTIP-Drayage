﻿using System;

namespace PAI.FRATIS.Wrappers.WebFleet.Model
{
    public class WebFleetStandStill
    {
        public string ObjectNumber { get; set; }
        public DateTime? StartTime { get; set; }
        public DateTime? EndTime { get; set; }
        public WebFleetPosition Position { get; set; }
    }
}
