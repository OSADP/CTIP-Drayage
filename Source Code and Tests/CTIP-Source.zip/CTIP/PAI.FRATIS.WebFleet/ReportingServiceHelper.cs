﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PAI.FRATIS.Wrappers.WebFleet.TripReportingService;

namespace PAI.FRATIS.Wrappers.WebFleet
{
    public static class ReportingServiceHelper
    {
        public static DateRangePattern GetDateRangePattern(SelectionTimeSpan timeSpanRange)
        {
            switch (timeSpanRange)
            {
                case SelectionTimeSpan.Today:
                    return DateRangePattern.D0;
                case SelectionTimeSpan.Yesterday:
                    return DateRangePattern.Dm1;
                case SelectionTimeSpan.ThisWeek:
                    return DateRangePattern.W0;
                case SelectionTimeSpan.LastWeek:
                    return DateRangePattern.Wm1;
                case SelectionTimeSpan.ThisMonth:
                    return DateRangePattern.M0;
                case SelectionTimeSpan.LastMonth:
                    return DateRangePattern.Mm1;
                case SelectionTimeSpan.ThisYear:
                    return DateRangePattern.Y0;
                default:
                    return DateRangePattern.D0; // default to today
            }
        }

    }
}
