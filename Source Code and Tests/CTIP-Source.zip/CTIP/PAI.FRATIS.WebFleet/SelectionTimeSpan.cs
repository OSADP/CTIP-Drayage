﻿namespace PAI.FRATIS.Wrappers.WebFleet
{
    public enum SelectionTimeSpan : int
    {
        Unspecified=0,
        Today=1,
        Yesterday=2,
        ThisWeek=3,
        LastWeek=4,
        ThisMonth=5,
        LastMonth=6,
        ThisYear=7
    }
}