﻿namespace PAI.FRATIS.Wrappers.WebFleet.Settings
{
    public class WebFleetSettings
    {
        public static string AccountName { get; set; }

        public static string UserName { get; set; }

        public static string Password { get; set; }

        public static string ApiKey { get; set; }

        static WebFleetSettings()
        {
            AccountName = "logistics-jamac";
            UserName = "PAI";
            Password = "manager";
            ApiKey = "1EA66960-0934-11E2-9C6C-FF3AAEFC9456";
        }
    }

    
}
