﻿using System;
using System.Collections.Generic;
using System.Linq;
using PAI.FRATIS.Wrappers.WebFleet.Mapping;
using PAI.FRATIS.Wrappers.WebFleet.Model;
using PAI.FRATIS.Wrappers.WebFleet.Settings;
using PAI.FRATIS.Wrappers.WebFleet.AddressService;
using PAI.FRATIS.Wrappers.WebFleet.TripReportingService;
using AuthenticationParameters = PAI.FRATIS.Wrappers.WebFleet.AddressService.AuthenticationParameters;
using CompleteLocationWithAdditionalInformation = PAI.FRATIS.Wrappers.WebFleet.AddressService.CompleteLocationWithAdditionalInformation;
using DescribedLocation = PAI.FRATIS.Wrappers.WebFleet.AddressService.DescribedLocation;
using GeneralParameters = PAI.FRATIS.Wrappers.WebFleet.AddressService.GeneralParameters;
using GeoPosition = PAI.FRATIS.Wrappers.WebFleet.AddressService.GeoPosition;
using KnownLocales = PAI.FRATIS.Wrappers.WebFleet.AddressService.KnownLocales;
using KnownTimeZones = PAI.FRATIS.Wrappers.WebFleet.AddressService.KnownTimeZones;
using RoutingData = PAI.FRATIS.Wrappers.WebFleet.AddressService.RoutingData;
using ServiceOpResult = PAI.FRATIS.Wrappers.WebFleet.AddressService.ServiceOpResult;

namespace PAI.FRATIS.Wrappers.WebFleet
{
    public interface IWebFleetAddressService
    {
        WebFleetPosition GeocodeAddress(string city, string zip, string street, string streetNumber);

        WebFleetRouteEstimate CalculateRoute(WebFleetSettings settings, WebFleetPosition startPosition, WebFleetPosition endPosition,
                                                   bool useTraffic, DateTime? startDateTime = null);

        bool UpdateAddress(string identifier, string address1, string address2, string address3,
                           string city, string zip, string telephoneOffice, string telephoneMobile,
                           string telephonePrivate, string telephoneFax,
                           int? latitudeInt = null, int? longitudeInt = null);

        bool InsertAddress(string identifier, string address1, string address2, string address3,
                           string city, string zip, string telephoneOffice, string telephoneMobile,
                           string telephonePrivate, string telephoneFax,
                           int? latitudeInt = null, int? longitudeInt = null);

        bool DeleteAddress(string identifier);

        bool AttachAddressToGroup(string identifier, string groupName);

        bool DetachAddressToGroup(string identifier, string groupName);

        bool InsertAddressGroup(string groupName);

        bool DeleteAddressGroup(string groupName, bool deleteAddresses);
    }



    public class WebFleetAddressService : IWebFleetAddressService
    {
        private readonly IWebFleetMappingService _mappingService;

        public WebFleetAddressService(IWebFleetMappingService mappingService)
        {
            _mappingService = mappingService;
        }

        public AuthenticationParameters GetAuthenticationParameters()
        {
            var auth = new AuthenticationParameters()
            {
                accountName = WebFleetSettings.AccountName,
                userName = WebFleetSettings.UserName,
                password = WebFleetSettings.Password,
                apiKey = WebFleetSettings.ApiKey
            };

            return auth;
        }

        public GeneralParameters GetGeneralParameters()
        {
            return new GeneralParameters
            {
                locale = KnownLocales.US,
                timeZone = KnownTimeZones.America_New_York
            };
        }

        public bool HandleResult(ServiceOpResult result)
        {
            return result.statusCode == 0;
            // TODO - Log Errors to Logger Service
        }

        public WebFleetPosition GeocodeAddress(string city, string zip, string street, string streetNumber)
        {
            var webService = new addressClient();
            var result = new List<WebFleetPosition>();

            var response = webService.geocodeAddressRecord(GetAuthenticationParameters(), GetGeneralParameters(),
                                      new GeocodingByProviderParameter()
                                          {
                                              city = city,
                                              countryCode = "US",
                                              postcode = zip,
                                              provider = "0",   // 1 for new TomTom geocoding service, 0 for legacy
                                              street = street,
                                              streetNumber = streetNumber
                                          });

            if (HandleResult(response))
            {
                result.AddRange(from CompleteLocationWithAdditionalInformation loc in response.results select _mappingService.Map(loc));
            }
            return result.Count > 0 ? result[0] : null;
        }

        public WebFleetRouteEstimate CalculateRoute(WebFleetSettings settings, WebFleetPosition startPosition, WebFleetPosition endPosition, bool useTraffic, DateTime? startDateTime = null)
        {
            if (!startPosition.HasValidPoints() || !endPosition.HasValidPoints())
                throw new Exception("Lat Long must be specified for start and end locations");

            var webService = new addressClient();
            var result = new List<WebFleetRouteEstimate>();

            var routingParam = new RoutingParameter()
                {
                    useTraffic = true,
                    useTrafficSpecified = true,
                    endLatitude = endPosition.LatitudeInt.Value,
                    endLongitude = endPosition.LongitudeInt.Value,
                    startLatitude = startPosition.LatitudeInt.Value,
                    startLongitude = startPosition.LongitudeInt.Value,
                    routeType = RouteType.Quickest
                };

            if (startDateTime != null)
            {
                routingParam.startDateTimeSpecified = true;
                routingParam.startDateTime = startDateTime;
            }

            var response = webService.calcRouteSimple(GetAuthenticationParameters(), GetGeneralParameters(), routingParam);
            
            if (HandleResult(response))
            {
                result.AddRange(from RoutingData route in response.results select _mappingService.Map(route));
            }

            return result.FirstOrDefault();
        }

        public bool InsertAddress(string identifier, string address1, string address2, string address3,
                               string city, string zip, string telephoneOffice, string telephoneMobile,
                               string telephonePrivate, string telephoneFax,
                               int? latitudeInt = null, int? longitudeInt = null)
        {
            var webService = new addressClient();
            var response = webService.insertAddressRecord(GetAuthenticationParameters(), GetGeneralParameters(),
                                                          new AddressRecord()
                                                              {
                                                                  addressNo = identifier,
                                                                  name1 = address1,
                                                                  name2 = address2,
                                                                  name3 = address3,
                                                                  location = new DescribedLocation()
                                                                      {
                                                                          city = city,
                                                                          postcode = zip,
                                                                          geoPosition = new GeoPosition()
                                                                              {
                                                                                  latitudeSpecified =
                                                                                      latitudeInt.HasValue,
                                                                                  latitude = latitudeInt,
                                                                                  longitudeSpecified =
                                                                                      longitudeInt.HasValue,
                                                                                  longitude = longitudeInt
                                                                              }
                                                                      },
                                                                  colourSpecified = false
                                                              },
                                                          new AddressRecordGroup());
                                                    
            return HandleResult(response);
        }

        public bool UpdateAddress(string identifier, string address1, string address2, string address3,
                       string city, string zip, string telephoneOffice, string telephoneMobile,
                       string telephonePrivate, string telephoneFax,
                       int? latitudeInt = null, int? longitudeInt = null)
        {
            var webService = new addressClient();
            var response = webService.updateAddressRecord(GetAuthenticationParameters(), GetGeneralParameters(),
                                                    new AddressRecord()
                                                        {
                                                            addressNo = identifier,
                                                            name1 = address1,
                                                            name2 = address2,
                                                            name3 = address3,
                                                            location = new DescribedLocation()
                                                                {
                                                                    city = city,
                                                                    postcode = zip,
                                                                    geoPosition = new GeoPosition()

                                                                        {
                                                                            latitudeSpecified = latitudeInt.HasValue,
                                                                            latitude = latitudeInt,
                                                                            longitudeSpecified = longitudeInt.HasValue,
                                                                            longitude = longitudeInt
                                                                        }
                                                                },
                                                            colourSpecified = false
                                                        });
            return HandleResult(response);
        }

        public bool DeleteAddress(string identifier)
        {
            var webService = new addressClient();
            var response = webService.deleteAddressRecord(GetAuthenticationParameters(), GetGeneralParameters(),
                                                          new AddressRecordIdentity() {addressNo = identifier});
                                                    
            return HandleResult(response);            
        }

        public bool AttachAddressToGroup(string identifier, string groupName)
        {
            var webService = new addressClient();
            var response = webService.attachAddressRecordToGroup(GetAuthenticationParameters(), GetGeneralParameters(),
                                                                 new AddressRecordToGroupRelationship()
                                                                     {
                                                                         address =
                                                                             new AddressRecordIdentity()
                                                                                 {
                                                                                     addressNo = identifier
                                                                                 },
                                                                         group =
                                                                             new AddressRecordGroup()
                                                                                 {
                                                                                     uniqueName = groupName
                                                                                 }
                                                                     });
            return HandleResult(response);
        }

        public bool DetachAddressToGroup(string identifier, string groupName)
        {
            var webService = new addressClient();
            var response = webService.detachAddressRecordFromGroup(GetAuthenticationParameters(), GetGeneralParameters(),
                new AddressRecordToGroupRelationship()
                                                           {
                                                               address = new AddressRecordIdentity() { addressNo = identifier },
                                                               group = new AddressRecordGroup() { uniqueName = groupName }
                                                           });
            return HandleResult(response);
        }

        public bool InsertAddressGroup(string groupName)
        {
            var webService = new addressClient();
            var response = webService.insertAddressRecordGroup(GetAuthenticationParameters(), GetGeneralParameters(), 
                new AddressRecordGroup() {uniqueName = groupName});
            return HandleResult(response);
        }

        public bool DeleteAddressGroup(string groupName, bool deleteAddresses)
        {
            var webService = new addressClient();
            var response = webService.deleteAddressRecordGroup(GetAuthenticationParameters(), GetGeneralParameters(),
                new AddressRecordGroup()  {uniqueName = groupName},
                new AdvancedDeleteAddressRecordGroupParameter()
                                                             {
                                                                 deleteAddressRecordes = deleteAddresses,
                                                                 deleteAddressRecordesSpecified = true,
                                                             });
            return HandleResult(response);
        }

    }
}
