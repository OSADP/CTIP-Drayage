﻿using PAI.FRATIS.Wrappers.WebFleet.DriverManagementService;
using PAI.FRATIS.Wrappers.WebFleet.Settings;

namespace PAI.FRATIS.Wrappers.WebFleet
{
    public interface IWebFleetDriverService
    {
        bool AddDriver(string name, string driverNumber, string pin, string code);
        bool DeleteDriver(string driverNumber);

    }
    public class WebFleetDriverService : IWebFleetDriverService
    {
        public AuthenticationParameters GetAuthenticationParameters()
        {
            var auth = new AuthenticationParameters()
            {
                accountName = WebFleetSettings.AccountName,
                userName = WebFleetSettings.UserName,
                password = WebFleetSettings.Password,
                apiKey = WebFleetSettings.ApiKey
            };

            return auth;
        }

        public GeneralParameters GetGeneralParameters()
        {
            return new GeneralParameters
            {
                locale = KnownLocales.US,
                timeZone = KnownTimeZones.America_New_York
            };
        }

        public bool HandleResult(ServiceOpResult result)
        {
            return result.statusCode == 0;
            // TODO - Log Errors to Logger Service
        }

        public bool AddDriver(string name, string driverNo, string pin, string code)
        {
            var webService = new driverManagementClient();
            
            var webFleetDriver = new InsertDriverParameter
            {
                name = name,
                driverNo = driverNo,
                pin = pin,
                code = code
            };

            var response = webService.insertDriver(GetAuthenticationParameters(), GetGeneralParameters(), webFleetDriver);

            return HandleResult(response);
        }

        public bool DeleteDriver(string driverNumber)
        {
            var webService = new driverManagementClient();
            var webFleetDriver = new DeleteDriverParameter
            {
                driverNo = driverNumber
            };

            var response = webService.deleteDriver(GetAuthenticationParameters(), GetGeneralParameters(), webFleetDriver);

            return HandleResult(response);
        }

    }
}
