using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using NUnit.Framework;
using Ninject;
using PAI.Drayage.Optimization.Common;
using PAI.Drayage.Optimization.Model;
using PAI.Drayage.Optimization.Model.Orders;
using PAI.Drayage.Optimization.Services;

namespace Tests
{

    public class NodeFactoryTests : TestBase
    {
        INodeFactory nodeFactory;
        INodeFactory NodeFactory
        {
            get { return nodeFactory ?? (nodeFactory = Kernel.Get<INodeFactory>()); }
        }

        [SetUp]
        public void SetUp()
        {
            Kernel.Bind<IRouteStopService>().To<RouteStopService>().InSingletonScope();
            Kernel.Bind<INodeFactory>().To<NodeFactory>().InSingletonScope();
        }

        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void CreateJob_throws_NullReferenceException_when_job_is_null()
        {
            NodeFactory.CreateJobNode(default(Job));
        }

        [Test]
        [ExpectedException(typeof(OptimizationException))]
        public void CreateJob_throws_OptimizationException_when_job_has_no_stops()
        {
            NodeFactory.CreateJobNode(new Job());
        }

        [Test]
        [ExpectedException(typeof(OptimizationException))]
        public void CreateJob_throws_OptimizationException_when_job_window_is_too_long()
        {
            NodeFactory.CreateJobNode(new Job { Priority = 1, RouteStops = new Collection<RouteStop>(new List<RouteStop> { new RouteStop() }) });
        }

        [Test]
        [ExpectedException(typeof(OptimizationException))]
        public void CreateJob_throws_OptimizationException_when_job_does_not_have_a_location()
        {
            var job = CreateTestJob();
            foreach (var routeStop in job.RouteStops)
            {
                routeStop.Location = default(Location);
            }

            NodeFactory.CreateJobNode(job);
        }

        [Test]
        [ExpectedException(typeof(OptimizationException))]
        public void CreateJob_throws_OptimizationException_when_job_does_not_have_a_valid_window()
        {
            var job = CreateTestJob();
            var x = job.RouteStops.First().WindowEnd;
            job.RouteStops.First().WindowEnd = job.RouteStops.First().WindowStart;
            job.RouteStops.First().WindowStart = x;

            NodeFactory.CreateJobNode(job);
        }

        [Test]
        public void Created_Jobs_have_a_Priority_within_allowed_range()
        {
            for (var i = -5000; i <= 5000; i++)
            {
                var job = CreateTestJob();
                job.Priority = i;
                var jobNode = NodeFactory.CreateJobNode(job);
                Assert.LessOrEqual(jobNode.Priority, 3);
                Assert.GreaterOrEqual(jobNode.Priority, 1);
            }
        }

        Job CreateTestJob()
        {
            return
                new Job
                    {
                        Priority = 1,
                        RouteStops =
                            new List<RouteStop>
                                {
                                    new RouteStop()
                                        {
                                            WindowStart = new TimeSpan(DateTime.Now.AddHours(1).Ticks), 
                                            WindowEnd = new TimeSpan(DateTime.Now.AddHours(2).Ticks),
                                            Location = new Location()
                                                {
                                                    Latitude = 1,
                                                    Longitude = 1
                                                }
                                        },
                                    new RouteStop()
                                        {
                                            WindowStart = new TimeSpan(DateTime.Now.AddHours(3).Ticks), 
                                            WindowEnd = new TimeSpan(DateTime.Now.AddHours(4).Ticks),
                                            Location = new Location()
                                                {
                                                    Latitude = 1,
                                                    Longitude = 1
                                                }
                                        }
                                }
                    };
        }
    }
}