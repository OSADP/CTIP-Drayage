using Moq;
using Ninject;
using NUnit.Framework;
using Ninject.MockingKernel.Moq;
using PAI.Drayage.Optimization.Model.Metrics;
using PAI.Core;
using PAI.Drayage.Optimization.Common;
using PAI.Drayage.Optimization.Function;
using PAI.Drayage.Optimization.Geography;
using PAI.Drayage.Optimization.Model;
using PAI.Drayage.Optimization.Model.Node;
using PAI.Drayage.Optimization.Model.Orders;
using PAI.Drayage.Optimization.Services;
using System;
using System.Collections.Generic;
using System.Linq;

using PAI.Drayage.Optimization.Reporting.Services;

namespace Tests
{

    public class OptimizerTests : TestBase
    {
        private IList<Location> Locations { get; set; }
        private IList<Driver> Drivers { get; set; }
        private IList<Job> Jobs { get; set; }
        private Location StartLocation { get; set; }

        private IDrayageOptimizer _optimizer;
        private IDrayageOptimizer Optimizer
        {
            get
            {
               if (_optimizer == null)
               {
                   _optimizer = Kernel.Get<IDrayageOptimizer>();
                   _optimizer.Initialize();
               }
               return _optimizer;
            }
        }

        Driver placeHolderDriver;
        public Driver PlaceholderDriver
        {
            get
            {
                if (placeHolderDriver == null)
                {
                    placeHolderDriver =
                        new Driver()
                        {
                            IsHazmatEligible = true,
                            IsShortHaulEligible = true,
                            IsLongHaulEligible = true,
                            DisplayName = "Placeholder Driver",
                            StartingLocation = StartLocation,
                            AvailableDrivingHours = 11,
                            AvailableDutyHours = 14
                        };
                }
                return placeHolderDriver;
            }
            set 
            { 
                placeHolderDriver = value;
            }
        }

        [SetUp]
        public void SetUp()
        {
            Kernel.Bind<IDrayageOptimizer>().To<DrayageOptimizer>().InSingletonScope();
            Kernel.Bind<IPheromoneMatrix>().To<PheromoneMatrix>().InSingletonScope()
                .WithConstructorArgument("initialPheromoneValue", 0.0)
                .WithConstructorArgument("rho", 0.5)
                .WithConstructorArgument("q", 1000.0);
            Kernel.Bind<IRouteExitFunction>().To<RouteExitFunction>().InSingletonScope();
            Kernel.Bind<IRouteService>().To<RouteService>().InSingletonScope();
            Kernel.Bind<IRouteStopDelayService>().To<RouteStopDelayService>().InSingletonScope();
            Kernel.Bind<IRouteStopService>().To<RouteStopService>().InSingletonScope();
            Kernel.Bind<IStatisticsService>().To<StatisticsService>().InSingletonScope();
            Kernel.Bind<IObjectiveFunction>().To<DistanceObjectiveFunction>().InSingletonScope();
            Kernel.Bind<IRandomNumberGenerator>().To<RandomNumberGenerator>().InSingletonScope();
            Kernel.Bind<IProbabilityMatrix>().To<ProbabilityMatrix>().InSingletonScope();
            Kernel.Bind<INodeFactory>().To<NodeFactory>().InSingletonScope();

            Kernel.Bind<ILogger>().To<NullLogger>().InSingletonScope();
            Kernel.Bind<INodeService>()
                .To<NodeService>()
                .InSingletonScope()
                .WithConstructorArgument("configuration", new OptimizerConfiguration());
            Kernel.Bind<IDistanceService>().To<DistanceService>().InSingletonScope();
            Kernel.Bind<ITravelTimeEstimator>().To<TravelTimeEstimator>().InSingletonScope();

            Kernel.Bind<IReportingService>().To<ReportingService>().InSingletonScope();    // todo verify scope
            Kernel.Bind<IRouteSanitizer>().To<RouteSanitizer>().InSingletonScope();    // todo verify scope

            // prepare mock data
            StartLocation = MockData.GetMockLocations(1, "Driver").FirstOrDefault();
            Locations = MockData.GetMockLocations(20);
            Drivers = MockData.GetMockDrivers(10, StartLocation);
            Jobs = MockData.GetJobs(50, Locations, true);
            PlaceholderDriver = null;
        }

        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void DrayageOptimizer_requires_Drivers()
        {
            Optimizer.BuildSolution(
                null,
                PlaceholderDriver,
                Jobs);
        }

        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void DrayageOptimizer_requires_PlaceholderDrivers()
        {
            Optimizer.BuildSolution(
                Drivers,
                null,
                Jobs);
        }

        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void DrayageOptimizer_requires_Jobs()
        {
            Optimizer.BuildSolution(
                Drivers,
                PlaceholderDriver,
                null);
        }

        [Test]
        [ExpectedException(typeof(OptimizationException))]
        public void DrayageOptimizer_requires_Jobs_has_at_least_one_Job()
        {
            Optimizer.BuildSolution(
                Drivers,
                PlaceholderDriver,
                new List<Job>());
        }

        [Test]
        [ExpectedException(typeof(OptimizationException))]
        public void DrayageOptimizer_must_be_initialized()
        {
            _optimizer = Kernel.Get<IDrayageOptimizer>();
            _optimizer.BuildSolution(
                Drivers,
                PlaceholderDriver,
                new List<Job>());
        }

        private class OptimizerParameters
        {
            public Mock<IProbabilityMatrix> ProbabilityMatrix { get; set; }
            public Mock<IRouteService> RouteService { get; set; }
            public Mock<INodeService> NodeService { get; set; }
            public Mock<IRouteStopService> RouteStopService { get; set; }
            public Mock<IRouteExitFunction> RouteExitFunction { get; set; }
            public Mock<ILogger> Logger { get; set; }
            public Mock<IPheromoneMatrix> PheromoneMatrix { get; set; }
            public Mock<IRandomNumberGenerator> RandomNumberGenerator { get; set; }
            public Mock<INodeFactory> NodeFactory { get; set; }

            public int PheromoneUpdateFrequency { get; set; }
            
            public OptimizerParameters()
            {
                ProbabilityMatrix = new Mock<IProbabilityMatrix>();
                RouteService = new Mock<IRouteService>();
                NodeService = new Mock<INodeService>();
                RouteStopService = new Mock<IRouteStopService>();
                RouteExitFunction = new Mock<IRouteExitFunction>();
                Logger = new Mock<ILogger>();
                PheromoneMatrix = new Mock<IPheromoneMatrix>();
                RandomNumberGenerator = new Mock<IRandomNumberGenerator>();
                NodeFactory = new Mock<INodeFactory>();
            }
        }

        [Test]
        public void Optimizer_Clears_Pheromone_Matrix()
        {
            var parameters = SetupOptimizerParameters();

            parameters.PheromoneMatrix.Verify(x => x.Clear());
        }

        [Test]
        public void BuildSolution_randomizes_the_list_of_drivers_and_jobs()
        {
            var parameters = SetupOptimizerParameters();

            parameters.RandomNumberGenerator.Verify(x => x.Next(), Times.Exactly(Drivers.Count + Jobs.Count));
        }

        [Test]
        public void BuildSolution_calls_RouteService_GetBestSolution()
        {
            var maxiterations = 50;
            var parameters = SetupOptimizerParameters(maxiterations);

            parameters.RouteService.Verify(x => x.GetBestSolution(It.IsAny<Solution>(), It.IsAny<Solution>()), Times.Exactly(maxiterations / 2));
        }

        [Test]
        public void BuildSolution_update_the_pheromone_matrix()
        {
            var parameters = SetupOptimizerParameters();

            parameters.PheromoneMatrix.Verify(x => x.UpdatePheromoneMatrix(It.IsAny<Solution>()), Times.Exactly(999 * parameters.PheromoneUpdateFrequency + 1));
        }

        [Test]
        public void GenerateRouteSolution_calls_probability_matrix_GetNominatedElement()
        {
            var parameters = SetupOptimizerParameters();

            parameters.ProbabilityMatrix.Verify(x => x.GetNominatedElement(It.IsAny<IList<ProbabilityItem>>()), Times.Exactly(500000));
        }

        [Test]
        public void GenerateRouteSolution_calls_RouteService_CreateRouteSolution()
        {
            var parameters = SetupOptimizerParameters();

            parameters.RouteService.Verify(x => x.CreateRouteSolution(It.IsAny<IEnumerable<INode>>(), It.IsAny<DriverNode>()), Times.Exactly(500000));
        }

        [Test]
        public void Can_prepare_mock_data()
        {
            Assert.That(StartLocation != null);
            Assert.That(Locations != null && Locations.Any(), "Mock Locations not ready");
            Assert.That(Drivers != null && Drivers.Any(), "Mock Drivers not ready");
            Assert.That(Jobs != null && Jobs.Any(), "Mock Jobs not ready");

            var hazmatJobs = Jobs.Where(p => p.IsHazmat);
            var shortHaulJobs = Jobs.Where(p => p.IsShortHaul);
            var longHaulJobs = Jobs.Where(p => p.IsLongHaul);
            var type1Jobs = Jobs.Where(p => p.OrderType == 1);
            var type2Jobs = Jobs.Where(p => p.OrderType == 2);
            var type3Jobs = Jobs.Where(p => p.OrderType == 3);
            var p1Jobs = Jobs.Where(p => p.Priority == 1);
            var p2Jobs = Jobs.Where(p => p.Priority == 2);
            var p3Jobs = Jobs.Where(p => p.Priority == 3);

            Assert.That(hazmatJobs != null && hazmatJobs.Any());
            Assert.That(shortHaulJobs != null && shortHaulJobs.Any());
            Assert.That(longHaulJobs != null && longHaulJobs.Any());
            Assert.That(type1Jobs != null && type1Jobs.Any());
            Assert.That(type2Jobs != null && type2Jobs.Any());
            Assert.That(type3Jobs != null && type3Jobs.Any());
            Assert.That(p1Jobs != null && p1Jobs.Any());
            Assert.That(p2Jobs != null && p2Jobs.Any());
            Assert.That(p3Jobs != null && p3Jobs.Any());

            var hazmatDrivers = Drivers.Where(p => p.IsHazmatEligible);
            var shortHaulDrivers = Drivers.Where(p => p.IsShortHaulEligible);
            var longHaulDrivers = Drivers.Where(p => p.IsLongHaulEligible);
            var type1Drivers = Drivers.Where(p => p.OrderType == 1);
            var type2Drivers = Drivers.Where(p => p.OrderType == 2);
            var type3Drivers = Drivers.Where(p => p.OrderType == 3);

            Assert.That(hazmatDrivers != null && hazmatDrivers.Any());
            Assert.That(shortHaulDrivers != null && shortHaulDrivers.Any());
            Assert.That(longHaulDrivers != null && longHaulDrivers.Any());
            Assert.That(type1Drivers != null && type1Drivers.Any());
            Assert.That(type2Drivers != null && type2Drivers.Any());
            Assert.That(type3Drivers != null && type3Drivers.Any());
        }

        [Test]
        public void Can_only_send_hazmat_jobs_to_hazmat_drivers()
        {
            var hazmatJobs = Jobs.Where(p => p.IsHazmat).ToList();
            var hazmatIneligibleDrivers = Drivers.Where(p => !p.IsHazmatEligible).ToList();

            PlaceholderDriver.IsHazmatEligible = false;

            var solution = Optimizer.BuildSolution(
                hazmatIneligibleDrivers,
                PlaceholderDriver,
                hazmatJobs);

            Assert.That(hazmatJobs.Any(), "No hazmat mock jobs identified");
            Assert.That(hazmatIneligibleDrivers.Any(), "No hazmat ineligible mock drivers identified");
            Assert.That(solution.UnassignedJobNodes.Count > 0 && solution.RouteSolutions.Sum(x => x.JobCount) == 0, "Ineligible driver has been assigned a hazmat job");
        }

        [Test]
        public void Can_driver_only_do_appropriate_order_types()
        {
            var type3Drivers = SetMaximumDriverEligibility(Drivers.Where(p => p.OrderType == 3));
            var type2Orders = Jobs.Where(p => p.OrderType == 2).Take(4).ToList();
            var type3Orders = Jobs.Where(p => p.OrderType == 3).Take(4).ToList();

            Assert.That(type3Drivers.Any(), "No mock drivers identified");
            Assert.That(type2Orders.Any(), "No mock jobs - order type 2 identified");
            Assert.That(type3Orders.Any(), "No mock jobs - order type 3 identified");

            PlaceholderDriver.OrderType = 3;

            var solutionUnfeasible = Optimizer.BuildSolution(
                type3Drivers,
                PlaceholderDriver,
                type2Orders);

            var solutionFeasible = Optimizer.BuildSolution(
                type3Drivers,
                PlaceholderDriver,
                type3Orders);

            var infeasibleJobs = solutionUnfeasible.RouteSolutions.Sum(x => x.JobCount);
            var feasibleJobs = solutionFeasible.RouteSolutions.Sum(x => x.JobCount);
            Assert.That(solutionUnfeasible.UnassignedJobNodes.Count > 0 && infeasibleJobs == 0, "Ineligible driver has been assigned a job");
            Assert.That(solutionFeasible.UnassignedJobNodes.Count == 0 && feasibleJobs > 0, "A job was unassigned");

        }

        [Test]
        public void Can_create_jobnode_with_jobnodefactory()
        {
            var job = Jobs.FirstOrDefault();
            var jobNodeFactory = Kernel.Get<INodeFactory>();

            var jobNode = jobNodeFactory.CreateJobNode(job);

            Assert.That(job != null);
            Assert.That(job.RouteStops != null);
            Assert.That(job.RouteStops.Count > 1);
            Assert.That(jobNode != null);            
        }

        [Test]
        public void Can_prioritize_orders()
        {
            var priorityJobs = Jobs.Where(p => p.Priority >= 3).Take(5).ToList();
            var otherJobs = Jobs.Where(p => p.Priority < 3).Take(15).ToList();
            var drivers = SetMaximumDriverEligibility(Drivers, true).Take((priorityJobs.Count / 5) + 1).ToList();

            var solution = Optimizer.BuildSolution(
                drivers,
                PlaceholderDriver,
                priorityJobs.Concat(otherJobs).ToList());

            var priorityJobIds = new HashSet<int>(priorityJobs.Select(p => p.Id));
            foreach (var rs in solution.RouteSolutions)
            {
                foreach (JobNode node in rs.Nodes)
                {
                    priorityJobIds.Remove(node.Job.Id);
                }
            }

            Assert.That(priorityJobIds.Count == 0, "Not all priority jobs were given in a route solution");
        }

        /// <summary>
        /// Can build a simple optimization solution
        /// </summary>
        [Test]
        public void Can_build_solution()
        {
            var solution = Optimizer.BuildSolution(
                SetMaximumDriverEligibility(Drivers.Take(1).ToList(), true),
                PlaceholderDriver,
                Jobs.Take(5).ToList());

            Assert.That(solution != null, "Solution is null");
            Assert.That(solution.RouteSolutions.Any(), "Solution has no route solutions");
        }

        [Test]
        public void Can_test_route_stop_second_window()
        {
            var drivers = SetMaximumDriverEligibility(Drivers.Where(p => p.OrderType == 1)).Take(1).ToList();
            var job = Jobs.FirstOrDefault(p => p.OrderType == 3);

            var solution = Optimizer.BuildSolution(drivers, PlaceholderDriver, new List<Job>() { job });

            foreach (var rs in solution.RouteSolutions)
            {
                Console.WriteLine("Driver {0}", rs.DriverNode.Driver.DisplayName);
                foreach (var node in rs.Nodes)
                {
                    Console.WriteLine("\tJob Priority {0}", node.Priority);

                }
            }
        }

        [Test]
        public void Can_test_prioritization_of_orders()
        {
            var type1Drivers = SetMaximumDriverEligibility(Drivers.Where(p => p.OrderType == 1));

            var priorityOrders = Jobs.Where(p => p.OrderType == 1).Take(32).ToList();
            var normalOrders = Jobs.Where(p => p.OrderType == 3).Take(4).ToList();

            var jobs = new List<Job>();
            jobs.AddRange(priorityOrders);
            jobs.AddRange(normalOrders);

            var solution = Optimizer.BuildSolution(type1Drivers, PlaceholderDriver, jobs);

            int normalJobCount = 0;
            int priorityJobCount = 0;

            foreach (var rs in solution.RouteSolutions)
            {
                Console.WriteLine("Driver {0}", rs.DriverNode.Driver.DisplayName);
                foreach (var node in rs.Nodes)
                {
                    Console.WriteLine("\tJob Priority {0}", node.Priority);
                    if (node.Priority == 3)
                    {
                        priorityJobCount++;
                    }
                    else
                    {
                        normalJobCount++;
                    }
                }

                Console.WriteLine("\n\tNormal Count: {0}     Priority Count: {1}", normalJobCount, priorityJobCount);
            }
        }

        /// <summary>
        /// Set the drivers eligibility status to true
        /// </summary>
        /// <param name="drivers"></param>
        /// <param name="resetOrderTypeValue"></param>
        /// <returns></returns>
        private IList<Driver> SetMaximumDriverEligibility(IEnumerable<Driver> drivers, bool resetOrderTypeValue = false)
        {
            var result = drivers.ToList();
            foreach (var d in result)
            {
                d.IsHazmatEligible = true;
                d.IsLongHaulEligible = true;
                d.IsShortHaulEligible = true;
                
                if (resetOrderTypeValue)
                {
                    d.OrderType = 1;    // highest setting, eligible for all order types
                }

            }
            return result;
        }

        OptimizerParameters SetupOptimizerParameters(int? maxIterations = null)
        {
            var parameters = new OptimizerParameters();

            var jobNode = new JobNode();
            jobNode.Job = new Job();
            jobNode.Job.OrderType = 99;

            parameters.NodeFactory
                      .Setup(x => x.CreateJobNode(It.IsAny<Job>()))
                      .Returns(jobNode);
            parameters.RouteStopService
                      .Setup(x => x.CalculateRouteStatistics(It.IsAny<IList<RouteStop>>(), false))
                      .Returns(new RouteStatistics());
            parameters.RouteService
                      .Setup(x => x.CreateRouteSolution(It.IsAny<IEnumerable<INode>>(), It.IsAny<DriverNode>()))
                      .Returns(new NodeRouteSolution());
            parameters.NodeService
                      .Setup(x => x.GetNodeTiming(It.IsAny<INode>(), It.IsAny<INode>(), It.IsAny<TimeSpan>(), It.IsAny<RouteStatistics>()))
                      .Returns(new NodeTiming()
                          {
                              IsFeasableTimeWindow = true,
                              Node = jobNode
                          });
            parameters.NodeService
                      .Setup(x => x.GetNodeConnection(It.IsAny<INode>(), It.IsAny<INode>()))
                      .Returns(new NodeConnection());
            parameters.ProbabilityMatrix
                      .Setup(x => x.GetNominatedElement(It.IsAny<IList<ProbabilityItem>>()))
                      .Returns(jobNode);

            var optimizer =
                new DrayageOptimizer(
                    probabilityMatrix: parameters.ProbabilityMatrix.Object,
                    routeService: parameters.RouteService.Object,
                    nodeService: parameters.NodeService.Object,
                    routeStopService: parameters.RouteStopService.Object,
                    routeExitFunction: parameters.RouteExitFunction.Object,
                    logger: parameters.Logger.Object,
                    pheromoneMatrix: parameters.PheromoneMatrix.Object,
                    randomNumberGenerator: parameters.RandomNumberGenerator.Object,
                    nodeFactory: parameters.NodeFactory.Object
                    );

            optimizer.Initialize();
            if (maxIterations.HasValue)
            {
                optimizer.MaxIterations = maxIterations.Value;
            }
            parameters.PheromoneUpdateFrequency = optimizer.PheromoneUpdateFrequency;

            optimizer.BuildSolution(
                Drivers,
                PlaceholderDriver,
                Jobs
                );
            return parameters;
        }
    }
}