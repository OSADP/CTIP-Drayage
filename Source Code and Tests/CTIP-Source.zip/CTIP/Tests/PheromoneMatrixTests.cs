using System;
using Moq;
using NUnit.Framework;
using PAI.Drayage.Optimization.Function;
using PAI.Drayage.Optimization.Model.Metrics;
using PAI.Drayage.Optimization.Model.Node;
using PAI.Drayage.Optimization.Services;

namespace Tests
{

    public class PheromoneMatrixTests : TestBase
    {
        Mock<IObjectiveFunction> objectiveMeasureFunction;
        IPheromoneMatrix pheromoneMatrix;

        [SetUp]
        public void SetUp()
        {
            objectiveMeasureFunction = new Mock<IObjectiveFunction>();

            pheromoneMatrix = new PheromoneMatrix(0, 0.5, 1000, objectiveMeasureFunction.Object);
        }

        [Test]
        [ExpectedException(typeof (ArgumentNullException))]
        public void PheronomeMatrix_UpdatePheromoneMatrix_requires_a_Solution()
        {
            pheromoneMatrix.UpdatePheromoneMatrix(default(Solution));
        }

        [Test]
        public void PhermononeMatrix_delegates_to_IObjectiveFunction_to_get_ObjectiveMeasure()
        {
            pheromoneMatrix.UpdatePheromoneMatrix(new Solution());

            objectiveMeasureFunction.Verify(x => x.GetObjectiveMeasure(It.IsAny<RouteStatistics>()));
        }
    }
}