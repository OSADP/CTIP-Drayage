using System;
using System.Collections.Generic;
using System.Linq;
using Moq;
using NUnit.Framework;
using PAI.Drayage.Optimization.Common;
using PAI.Drayage.Optimization.Function;
using PAI.Drayage.Optimization.Model.Metrics;
using PAI.Drayage.Optimization.Model.Node;
using PAI.Drayage.Optimization.Model.Orders;
using PAI.Drayage.Optimization.Services;
using PAI.Core;

namespace Tests
{

    public class RouteServiceTests
    {
        Mock<ILogger> logger;
        Mock<IRouteExitFunction> routeExitFunction;
        Mock<INodeService> nodeService;
        Mock<IStatisticsService> statisticsService;
        IRouteService routeService;

        INode driver = 
            new DriverNode(new Driver());

        INode firstJob =
            new JobNode
                {
                    Job = new Job(),
                    RouteStatistics = new RouteStatistics
                        {
                            TotalExecutionTime = new TimeSpan(1, 0, 0)
                        }
                };

        INode secondJob =
            new JobNode
                {
                    Job = new Job(),
                    RouteStatistics = new RouteStatistics
                        {
                            TotalExecutionTime = new TimeSpan(0, 1, 0)
                        }
                };

        INode thirdJob =
            new JobNode
                {
                    Job = new Job(),
                    RouteStatistics = new RouteStatistics
                        {
                            TotalExecutionTime = new TimeSpan(0, 0, 1)
                        }
                };

        RouteStatistics DriverToFirst = 
            new RouteStatistics()
                {
                    TotalTravelTime = new TimeSpan(2, 0, 0, 0)
                };

        RouteStatistics FirstToSecond =
            new RouteStatistics()
                {
                    TotalTravelTime = new TimeSpan(0, 2, 0, 0)
                };

        RouteStatistics SecondToThird =
            new RouteStatistics()
                {
                    TotalTravelTime = new TimeSpan(0, 0, 2, 0)
                };

        RouteStatistics ThirdToDriver =
            new RouteStatistics()
                {
                    TotalTravelTime = new TimeSpan(0, 0, 0, 2)
                };

        [SetUp]
        public void SetUp()
        {
            logger = new Mock<ILogger>();
            routeExitFunction = new Mock<IRouteExitFunction>();
            nodeService = new Mock<INodeService>();
            statisticsService = new Mock<IStatisticsService>();
        }
        
        public void SetUpSystemUnderTest()
        {
            routeService = new RouteService(routeExitFunction.Object, nodeService.Object, statisticsService.Object, logger.Object);
        }

        [Test]
        public void RouteService_CalculateRouteStatistics_delegates_to_NodeService()
        {
            nodeService.Setup(x => x.GetNodeConnection(It.IsAny<INode>(), It.IsAny<INode>())).Returns(new NodeConnection());
            SetUpSystemUnderTest();
            routeService.CalculateRouteStatistics(null, null);
            nodeService.Verify(x => x.GetNodeConnection(It.IsAny<INode>(), It.IsAny<INode>()));
        }

        [Test]
        [ExpectedException(typeof (ArgumentNullException))]
        public void GetBestFeasableSolution_requires_a_list_of_nodes()
        {
            SetUpSystemUnderTest();
            routeService.GetBestFeasableSolution(null, new DriverNode(new Driver()), new NodeRouteSolution());
        }

        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void GetBestFeasableSolution_requires_a_driver()
        {
            SetUpSystemUnderTest();
            routeService.GetBestFeasableSolution(nodes, null, new NodeRouteSolution());
        }

        [Test]
        [ExpectedException(typeof(OptimizationException))]
        public void GetBestFeasableSolution_requires_a_list_of_nodes_with_stops()
        {
            nodeService.Setup(x => x.GetNodeConnection(It.IsAny<INode>(), It.IsAny<INode>())).Returns(new NodeConnection());
            nodeService.Setup(x => x.GetNodeTiming(It.IsAny<INode>(), It.IsAny<INode>(), It.IsAny<TimeSpan>(), It.IsAny<RouteStatistics>())).Returns(new NodeTiming());
            SetUpSystemUnderTest();
            routeService.GetBestFeasableSolution(new List<INode>(), new DriverNode(new Driver()), new NodeRouteSolution());
        }

        [Test]
        public void GetBestFeasableSolution_does_not_require_a_NodeRouteSolution()
        {
            nodeService.Setup(x => x.GetNodeConnection(It.IsAny<INode>(), It.IsAny<INode>())).Returns(new NodeConnection());
            nodeService.Setup(x => x.GetNodeTiming(It.IsAny<INode>(), It.IsAny<INode>(), It.IsAny<TimeSpan>(), It.IsAny<RouteStatistics>())).Returns(new NodeTiming());
            SetUpSystemUnderTest();
            var result = routeService.GetBestFeasableSolution(nodes, new DriverNode(new Driver()), null);
            Assert.AreEqual(null, result);
        }

        [Test]
        [ExpectedException(typeof (ArgumentNullException))]
        public void CreateRouteSolution_requires_a_collection_of_nodes()
        {
            SetUpSystemUnderTest();
            routeService.CreateRouteSolution(null, new DriverNode(new Driver()));
        }

        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void CreateRouteSolution_requires_a_driver_node()
        {
            SetUpSystemUnderTest();
            routeService.CreateRouteSolution(nodes, null);
        }

        [Test]
        public void CreateRouteSolution_returns_a_NodeRouteSolution()
        {
            nodeService.Setup(x => x.GetNodeConnection(It.IsAny<INode>(), It.IsAny<INode>())).Returns(new NodeConnection());
            SetUpSystemUnderTest();
            var result = routeService.CreateRouteSolution(nodes, new DriverNode(new Driver()));
            Assert.IsInstanceOf<NodeRouteSolution>(result);
        }

        [Test]
        public void CreateRouteSolution_returns_a_solution_whose_statistics_are_equal_to_the_sum_of_the_nodes_statastics()
        {
            nodeService.Setup(x => x.GetNodeConnection(driver, firstJob)).Returns(new NodeConnection { RouteStatistics = DriverToFirst });
            nodeService.Setup(x => x.GetNodeConnection(firstJob, secondJob)).Returns(new NodeConnection { RouteStatistics = FirstToSecond });
            nodeService.Setup(x => x.GetNodeConnection(secondJob, thirdJob)).Returns(new NodeConnection { RouteStatistics = SecondToThird });
            nodeService.Setup(x => x.GetNodeConnection(thirdJob, driver)).Returns(new NodeConnection { RouteStatistics = ThirdToDriver });
            SetUpSystemUnderTest();
            var result = routeService.CreateRouteSolution(nodes, driver as DriverNode);
            var checkResult = new RouteStatistics();
            checkResult = nodes.Aggregate(checkResult, (current, node) => current + node.RouteStatistics);
            checkResult += DriverToFirst;
            checkResult += FirstToSecond;
            checkResult += SecondToThird;
            checkResult += ThirdToDriver;
            Assert.AreEqual(checkResult.TotalTime, result.RouteStatistics.TotalTime);
        }

        [Test]
        public void CalculateRouteStatistics_sums_the_statistics_of_the_submitted_nodes()
        {
            nodeService.Setup(x => x.GetNodeConnection(driver, firstJob)).Returns(new NodeConnection { RouteStatistics = DriverToFirst });
            SetUpSystemUnderTest();
            var result = routeService.CalculateRouteStatistics(driver, firstJob);
            Assert.AreEqual(result, DriverToFirst);
        }

        [Test]
        public void GetBestSolution_returns_the_solution_with_the_highest_total_priority_value()
        {
            var firstSolution = new NodeRouteSolution();
            var secondSolution = new NodeRouteSolution();
            for (var i = 0; i < 100; i++)
            {
                firstSolution.Nodes.Add(new JobNode());
                secondSolution.Nodes.Add(new JobNode());
            }
            secondSolution.Nodes = secondSolution.Nodes.Take(secondSolution.Nodes.Count/2).ToList();
            foreach (var node in secondSolution.Nodes)
            {
                node.Priority = 2;
            }
            secondSolution.Nodes.Add(new JobNode());

            SetUpSystemUnderTest();
            var result = routeService.GetBestSolution(firstSolution, secondSolution);
            Assert.AreEqual(secondSolution, result);

            firstSolution.Nodes = secondSolution.Nodes = new List<INode>();
            for (var i = 0; i < 100; i++)
            {
                firstSolution.Nodes.Add(new JobNode());
                secondSolution.Nodes.Add(new JobNode());
            }
            firstSolution.Nodes.Last().Priority = 2;
            result = routeService.GetBestSolution(firstSolution, secondSolution);
            Assert.AreEqual(firstSolution, result);
        }

        [Test]
        public void GetBestSolution_returns_the_solution_with_the_highest_total_priority_value_that_is_feasible()
        {
            var solution = new NodeRouteSolution();
            nodeService.Setup(x => x.GetNodeConnection(It.IsAny<INode>(), It.IsAny<INode>())).Returns(new NodeConnection());
            nodeService.Setup(x => x.GetNodeTiming(It.IsAny<INode>(), It.IsAny<INode>(), It.IsAny<TimeSpan>(), It.IsAny<RouteStatistics>())).Returns(new NodeTiming{IsFeasableTimeWindow = false});
            SetUpSystemUnderTest();
            var result = routeService.GetBestFeasableSolution(nodes, driver as DriverNode, solution);
            Assert.AreEqual(solution, result);
        }

        List<INode> nodes
        {
            get
            {
                return new List<INode>
                    {
                        firstJob,
                        secondJob,
                        thirdJob
                    };
            }
        }
    }
}