using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using Moq;
using NUnit.Framework;
using Ninject;
using PAI.Drayage.Optimization.Common;
using PAI.Drayage.Optimization.Geography;
using PAI.Drayage.Optimization.Model;
using PAI.Drayage.Optimization.Model.Metrics;
using PAI.Drayage.Optimization.Model.Orders;
using PAI.Drayage.Optimization.Services;
using PAI.Core;

namespace Tests
{
    public class RouteStopServiceTests : TestBase
    {
        Mock<IDistanceService> distanceService;
        Mock<IRouteStopDelayService> routeStopDelayService;
        const decimal testDistance = 1.5M;
        TimeSpan testTime = new TimeSpan(1);
        IList<RouteStop> stops = new List<RouteStop>
            {
                new RouteStop
                    {
                        Location = new Location(),
                        WindowEnd = new TimeSpan(12, 5, 0),
                        WindowStart = new TimeSpan(12, 0, 0)
                    },
                new RouteStop
                    {
                        Location = new Location(),
                        WindowEnd = new TimeSpan(13, 5, 0),
                        WindowStart = new TimeSpan(13, 0, 0)
                    },
                new RouteStop
                    {
                        Location = new Location(),
                        WindowEnd = new TimeSpan(14, 5, 0),
                        WindowStart = new TimeSpan(14, 0, 0)
                    }
            };

        readonly OptimizerConfiguration optimizerConfiguration =
            new OptimizerConfiguration
            {
                DefaultStopDelay = new TimeSpan(1, 1, 1, 1, 1),
                MaximumWaitTimeAtStop = new TimeSpan(0, 30, 0)
            };

        IRouteStopService routeStopService;
        IRouteStopService RouteStopService
        {
            get
            {
                return routeStopService ?? (routeStopService = new RouteStopService(distanceService.Object, optimizerConfiguration, routeStopDelayService.Object));
            }
        }

        [SetUp]
        public void SetUp()
        {
            routeStopService = null;
            base.BaseSetUp();
            distanceService = MockData.Kernel.GetMock<IDistanceService>();
            routeStopDelayService = MockData.Kernel.GetMock<IRouteStopDelayService>();
        }

        [Test]
        public void CalculateTripLength_delegates_distance_calculation_to_DistanceService_CalculateDistance()
        {
            distanceService.Setup(x => x.CalculateDistance(It.IsAny<Location>(), It.IsAny<Location>())).Returns(new TripLength(testDistance, testTime));
            RouteStopService.CalculateTripLength(new RouteStop(), new RouteStop());
            distanceService.Verify(x => x.CalculateDistance(It.IsAny<Location>(), It.IsAny<Location>()), Times.Once);
        }

        [Test]
        public void CalculateRouteStatistics_calls_DistanceService_once_per_leg()
        {
            distanceService.Setup(x => x.CalculateDistance(It.IsAny<Location>(), It.IsAny<Location>())).Returns(new TripLength(testDistance, testTime));
            RouteStopService.CalculateRouteStatistics(stops, false);
            distanceService.Verify(x => x.CalculateDistance(It.IsAny<Location>(), It.IsAny<Location>()), Times.Exactly(stops.Count - 1));
        }

        [Test]
        public void CalculateRouteStatistics_returns_sum_of_the_leg_travel_time_and_distance()
        {
            distanceService.Setup(x => x.CalculateDistance(It.IsAny<Location>(), It.IsAny<Location>())).Returns(new TripLength(testDistance, testTime));
            var result = RouteStopService.CalculateRouteStatistics(stops, false);
            Assert.AreEqual(testDistance * (stops.Count - 1), result.TotalTravelDistance);
            Assert.AreEqual(testTime.Ticks * (stops.Count - 1), result.TotalTime.Ticks);
        }

        [Test]
        public void CalculateRouteSegmentStatistics_calculates_each_leg_and_sets_times()
        {
            distanceService.Setup(x => x.CalculateDistance(It.IsAny<Location>(), It.IsAny<Location>())).Returns(new TripLength(testDistance, testTime));
            SetUp();
            testTime = stops[0].WindowStart;
            var result = RouteStopService.CalculateRouteSegmentStatistics(stops, testTime);
            Assert.AreEqual(stops.Count - 1, result.Count);
            var currentTime = testTime;
            for (var i = 0; i < stops.Count - 1; i++)
            {
                Assert.AreEqual(currentTime, result[i].StartTime);
                currentTime = result[i].EndTime;
                Assert.AreEqual(currentTime, result[i].EndTime);
            }
        }

        [Test]
        public void CreateRouteSegmentStatistics_sets_whiffed_if_arrival_time_is_late()
        {
            var startTime = stops[2].WindowEnd;
            distanceService.Setup(x => x.CalculateDistance(It.IsAny<Location>(), It.IsAny<Location>())).Returns(new TripLength(testDistance, testTime));
            var result = RouteStopService.CalculateRouteSegmentStatistics(stops, startTime);

            Assert.IsTrue(result.All(x => x.WhiffedTimeWindow));
        }

        [Test]
        public void CreateRouteSegmentStatistics_sets_whiffed_if_arrival_time_is_earlier_than_configured_wait_time()
        {
            var waitTime = new TimeSpan(6, 0, 0);
            var startTime = stops[0].WindowStart.Subtract(waitTime);
            distanceService.Setup(x => x.CalculateDistance(It.IsAny<Location>(), It.IsAny<Location>())).Returns(new TripLength(testDistance, testTime));
            SetUp();
            var result = RouteStopService.CalculateRouteSegmentStatistics(stops, startTime);

            Assert.IsTrue(result.All(x => x.WhiffedTimeWindow));
        }

        [Test]
        public void CreateRouteSegmentStatistics_sets_wait_time_if_start_is_earlier_than_configured_wait_time()
        {
            var earlytime = new TimeSpan(1, 0, 0);
            var startTime = stops[0].WindowStart.Subtract(earlytime);
            distanceService.Setup(x => x.CalculateDistance(It.IsAny<Location>(), It.IsAny<Location>())).Returns(new TripLength(testDistance, testTime));
            var result = RouteStopService.CalculateRouteSegmentStatistics(stops, startTime);

            for (var i = 0; i < result.Count; i++)
            {
                Assert.AreNotEqual(TimeSpan.Zero, result[i].Statistics.TotalWaitTime);
            }
        }

        [Test]
        public void CreateRouteSegmentStatistics_does_not_sets_wait_time_or_whiffed_if_start_times_are_at_or_within_window()
        {
            testTime = new TimeSpan(0, 55, 0);
            optimizerConfiguration.MaximumWaitTimeAtStop = new TimeSpan(0, 5, 0);

            var headStart = new TimeSpan(optimizerConfiguration.MaximumWaitTimeAtStop.Ticks / 2);
            var startTime = stops[1].WindowStart.Subtract(headStart);
            distanceService.Setup(x => x.CalculateDistance(It.IsAny<Location>(), It.IsAny<Location>())).Returns(new TripLength(testDistance, testTime));
            var result = RouteStopService.CalculateRouteSegmentStatistics(stops, startTime);

            for (var i = 0; i < result.Count; i++)
            {
                Assert.AreEqual(result[i].Statistics.TotalTime.Subtract(result[i].Statistics.TotalTravelTime), result[i].Statistics.TotalWaitTime);
                Assert.IsFalse(result[i].WhiffedTimeWindow);
            }
        }

        [Test]
        public void CreateRouteSegmentStatistics_delegates_to_Route_stop_Delay_Service_to_get_execution_time()
        {
            distanceService.Setup(x => x.CalculateDistance(It.IsAny<Location>(), It.IsAny<Location>())).Returns(new TripLength(testDistance, testTime));
            var result = RouteStopService.CalculateRouteSegmentStatistics(stops, stops[0].WindowStart);
            routeStopDelayService.Verify(x => x.GetDelay(It.IsAny<RouteStop>()), Times.Exactly(stops.Count - 1));
        }
    }
}