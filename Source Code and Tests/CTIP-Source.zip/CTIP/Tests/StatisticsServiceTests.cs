using System;
using System.Collections.Generic;
using System.Diagnostics;
using Moq;
using NUnit.Framework;
using PAI.Drayage.Optimization.Function;
using PAI.Drayage.Optimization.Model;
using PAI.Drayage.Optimization.Model.Equipment;
using PAI.Drayage.Optimization.Model.Metrics;
using PAI.Drayage.Optimization.Model.Node;
using PAI.Drayage.Optimization.Model.Orders;
using PAI.Drayage.Optimization.Services;

namespace Tests
{
    public class StatisticsServiceTests : TestBase
    {
        Mock<IObjectiveFunction> objectiveFunction;

        IStatisticsService statisticsService;
        IStatisticsService StatisticsService
        {
            get
            {
                return statisticsService ?? (statisticsService = new StatisticsService(objectiveFunction.Object));
            }
        }

        [SetUp]
        public void SetUp()
        {
            statisticsService = null;
            objectiveFunction = Kernel.GetMock<IObjectiveFunction>();
        }

        [Test]
        public void CompareRouteStatistics_delegates_to_ObjectiveFunction_to_evaluate_statistics()
        {
            objectiveFunction.Setup(x => x.GetObjectiveMeasure(It.IsAny<RouteStatistics>())).Returns(default(double));
            StatisticsService.CompareRouteStatistics(new RouteStatistics(), new RouteStatistics());
            objectiveFunction.Verify(x => x.GetObjectiveMeasure(It.IsAny<RouteStatistics>()), Times.Exactly(2));
        }

        [Test]
        public void CompareRouteStatistics_returns_the_route_with_the_greatest_value()
        {
            var leftRoute = new RouteStatistics
                {
                    TotalTravelTime = new TimeSpan(1)
                };
            var rightRoute = new RouteStatistics
            {
                TotalTravelTime = new TimeSpan(100)
            };
            objectiveFunction.Setup(x => x.GetObjectiveMeasure(leftRoute)).Returns(2.5);
            objectiveFunction.Setup(x => x.GetObjectiveMeasure(rightRoute)).Returns(20.5);
            var result = StatisticsService.CompareRouteStatistics(leftRoute, rightRoute);
            Assert.AreEqual(-1, result);
            result = StatisticsService.CompareRouteStatistics(rightRoute, leftRoute);
            Assert.AreEqual(1, result);
            result = StatisticsService.CompareRouteStatistics(leftRoute, leftRoute);
            Assert.AreEqual(0, result);
        }
    }
}