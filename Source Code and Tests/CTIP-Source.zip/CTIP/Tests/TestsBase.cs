﻿
using Ninject.MockingKernel.Moq;
using NUnit.Framework;

namespace Tests
{
    public class TestBase
    {
        public MoqMockingKernel Kernel { get; set; }

        [SetUp]
        public void BaseSetUp()
        {
            Kernel = new MoqMockingKernel();
            MockData.Kernel = Kernel;
        }
    }
}
